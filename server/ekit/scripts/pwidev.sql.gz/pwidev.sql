-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: pwikit
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BATCH`
--

DROP TABLE IF EXISTS `BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BATCH` (
  `TITLE` varchar(100) NOT NULL,
  `SID` varchar(12) NOT NULL,
  `BID` int(11) NOT NULL,
  `UPLOADED_BY` varchar(20) NOT NULL,
  `ORIG_NAME` varchar(100) NOT NULL,
  `GOOD` int(11) NOT NULL,
  `BAD` int(11) NOT NULL,
  `UPLOAD_EPOCH` int(11) NOT NULL,
  `NAMES_FILE` varchar(100) NOT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `MODIFIED_EPOCH` int(11) DEFAULT NULL,
  `CLEAN_EPOCH` int(11) DEFAULT NULL,
  `DELETE_EPOCH` int(11) DEFAULT NULL,
  `TAG` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`BID`,`SID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH`
--

LOCK TABLES `BATCH` WRITE;
/*!40000 ALTER TABLE `BATCH` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT` (
  `CLID` int(11) NOT NULL,
  `CLNAME` varchar(20) NOT NULL,
  PRIMARY KEY (`CLID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES (1,'Triton');
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONTRACT`
--

DROP TABLE IF EXISTS `CONTRACT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONTRACT` (
  `COID` int(11) NOT NULL,
  `CLID` int(11) NOT NULL,
  `VID` int(11) NOT NULL,
  `START_EPOCH` int(11) NOT NULL,
  `END_EPOCH` int(11) NOT NULL,
  `EMAILS` int(11) NOT NULL,
  `DATA_FETCH` int(11) NOT NULL,
  `ALLOWED_JOBS` int(11) NOT NULL,
  PRIMARY KEY (`COID`),
  KEY `CLID` (`CLID`),
  KEY `VID` (`VID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONTRACT`
--

LOCK TABLES `CONTRACT` WRITE;
/*!40000 ALTER TABLE `CONTRACT` DISABLE KEYS */;
INSERT INTO `CONTRACT` VALUES (1,1,1,1146578400,1454504400,1,1,1);
/*!40000 ALTER TABLE `CONTRACT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DFS178`
--

DROP TABLE IF EXISTS `DFS178`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DFS178` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `STAT` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DFS178`
--

LOCK TABLES `DFS178` WRITE;
/*!40000 ALTER TABLE `DFS178` DISABLE KEYS */;
/*!40000 ALTER TABLE `DFS178` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DFS178_E`
--

DROP TABLE IF EXISTS `DFS178_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DFS178_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DFS178_E`
--

LOCK TABLES `DFS178_E` WRITE;
/*!40000 ALTER TABLE `DFS178_E` DISABLE KEYS */;
/*!40000 ALTER TABLE `DFS178_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_MSG`
--

DROP TABLE IF EXISTS `EMAIL_MSG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_MSG` (
  `EMAIL_MSG_ID` int(11) NOT NULL,
  `EMAIL_TRACK_ID` int(11) NOT NULL,
  `MESSAGE_NAME` varchar(100) NOT NULL,
  `MESSAGE_INTERVAL` int(11) NOT NULL,
  `TEMPLATE` varchar(100) NOT NULL,
  `USE_HTML_FLAG` int(11) DEFAULT '1',
  `USE_PLAIN_FLAG` int(11) DEFAULT '1',
  `ALERT_FLAG` int(11) DEFAULT '0',
  `ALERT_EMAIL` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`EMAIL_MSG_ID`),
  KEY `EMAIL_TRACK_ID` (`EMAIL_TRACK_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_MSG`
--

LOCK TABLES `EMAIL_MSG` WRITE;
/*!40000 ALTER TABLE `EMAIL_MSG` DISABLE KEYS */;
INSERT INTO `EMAIL_MSG` VALUES (1,1,'invite',0,'peer',1,1,0,NULL),(2,2,'reminder1',0,'peer_reminder1',1,1,0,NULL),(3,3,'reminder2',0,'peer_reminder2',1,1,0,NULL),(5,5,'invite first go',0,'participant',1,1,0,NULL),(6,6,'reminder1 first go',0,'participant_reminder1',1,1,0,NULL),(7,7,'reminder2 first go',0,'participant_reminder2',1,1,0,NULL),(4,4,'reminder3',0,'peer_reminder3',1,1,0,NULL),(9,9,'execinvite',0,'execinvite',1,1,0,NULL),(10,5,'escalation',86400,'escalate',1,1,1,'[%execemail%]'),(11,1,'escalate',86400,'peer_escalate',1,1,1,'[%execemail%]'),(8,8,'reminder3 first go',0,'participant_reminder3',1,1,0,NULL),(15,6,'escalation',86400,'escalate',1,1,1,'[%execemail%]'),(12,2,'escalate',86400,'peer_escalate',1,1,1,'[%execemail%]'),(18,10,'first invite',0,'boss',1,1,0,NULL),(13,3,'escalate',86400,'peer_escalate',1,1,1,'[%execemail%]'),(16,7,'escalation',86400,'escalate',1,1,1,'[%execemail%]'),(19,11,'first reminder 1',0,'boss_reminder1',1,1,0,NULL),(14,4,'escalate',86400,'peer_escalate',1,1,1,'[%execemail%]'),(20,12,'first reminder2',0,'boss_reminder2',1,1,0,NULL),(21,13,'first reminder3',0,'boss_reminder3',1,1,0,NULL),(17,8,'escalation',86400,'escalate',1,1,1,'[%execemail%]');
/*!40000 ALTER TABLE `EMAIL_MSG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_MSG_STATUS`
--

DROP TABLE IF EXISTS `EMAIL_MSG_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_MSG_STATUS` (
  `EMAIL_MSG_STATUS_ID` int(11) NOT NULL,
  `EMAIL_TRACK_STATUS_ID` int(11) NOT NULL,
  `MESSAGE_STATUS_NAME` varchar(100) NOT NULL,
  `WORKING_TEMPLATE` varchar(100) NOT NULL,
  `USE_HTML_FLAG` int(11) NOT NULL,
  `USE_PLAIN_FLAG` int(11) NOT NULL,
  `ALERT_FLAG` int(11) DEFAULT '0',
  `ALERT_EMAIL` varchar(250) DEFAULT NULL,
  `CREATED_EPOCH` int(11) NOT NULL,
  `START_EPOCH` int(11) NOT NULL,
  `DONE_EPOCH` int(11) DEFAULT NULL,
  `SENT_MSG` varchar(250) DEFAULT NULL,
  `SENT_ERROR` varchar(250) DEFAULT NULL,
  `SENDMAIL_ID` varchar(250) DEFAULT NULL,
  `RETURN_MSG` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`EMAIL_MSG_STATUS_ID`),
  KEY `EMAIL_TRACK_STATUS_ID` (`EMAIL_TRACK_STATUS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_MSG_STATUS`
--

LOCK TABLES `EMAIL_MSG_STATUS` WRITE;
/*!40000 ALTER TABLE `EMAIL_MSG_STATUS` DISABLE KEYS */;
INSERT INTO `EMAIL_MSG_STATUS` VALUES (21,13,'escalation','escalate',1,1,1,'[%execemail%]',1147220311,1149121080,NULL,NULL,NULL,NULL,NULL),(20,13,'reminder3 first go','participant_reminder3',1,1,0,NULL,1147220311,1149034680,NULL,NULL,NULL,NULL,NULL),(19,12,'escalation','escalate',1,1,1,'[%execemail%]',1147220311,1148516280,NULL,NULL,NULL,NULL,NULL),(18,12,'reminder2 first go','participant_reminder2',1,1,0,NULL,1147220311,1148429880,NULL,NULL,NULL,NULL,NULL),(17,11,'escalation','escalate',1,1,1,'[%execemail%]',1147220310,1147911480,NULL,NULL,NULL,NULL,NULL),(16,11,'reminder1 first go','participant_reminder1',1,1,0,NULL,1147220310,1147825080,NULL,NULL,NULL,NULL,NULL),(15,10,'escalation','escalate',1,1,1,'[%execemail%]',1147220310,1147306680,NULL,NULL,NULL,NULL,NULL),(11,7,'first reminder 1','boss_reminder1',1,1,0,NULL,1147220187,1147824960,1148965215,'Sending template \'boss_reminder1\' email about \'Reminder: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,'37DB0761F86',NULL),(12,8,'first reminder2','boss_reminder2',1,1,0,NULL,1147220187,1148429760,1148965218,'Sending template \'boss_reminder2\' email about \'Reminder 2: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,'64FF0B60A98',NULL),(13,9,'first reminder3','boss_reminder3',1,1,0,NULL,1147220187,1149034560,1149120240,'Sending template \'boss_reminder3\' email about \'Reminder 3: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,'1B52F3D3217',NULL),(14,10,'invite first go','participant',1,1,0,NULL,1147220310,1147220280,NULL,NULL,NULL,NULL,NULL),(9,5,'execinvite','execinvite',1,1,0,NULL,1147220187,1147220160,1148965198,'Sending template \'execinvite\' email about \'PWI EMAIL: Andrew Creer has been emailed\' to Andrew Creer <ac@market-research.com> : OK',NULL,'22D6EB609C7',NULL),(10,6,'first invite','boss',1,1,0,NULL,1147220187,1147220160,1148965201,'Sending template \'boss\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,'816DDF072A',NULL),(1,1,'invite first go','participant',1,1,0,NULL,1147220187,1147220160,1148965206,'Sending template \'participant\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,'5D591F0725',NULL),(2,1,'escalation','escalate',1,1,1,'[%execemail%]',1147220187,1147306560,1148965214,'Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,'7863DF074F',NULL),(3,2,'reminder1 first go','participant_reminder1',1,1,0,NULL,1147220187,1147824960,1148965216,'Sending template \'participant_reminder1\' email about \'Reminder: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,'318AC760B31',NULL),(4,2,'escalation','escalate',1,1,1,'[%execemail%]',1147220187,1147911360,1148965217,'Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,'30E44761F67',NULL),(5,3,'reminder2 first go','participant_reminder2',1,1,0,NULL,1147220187,1148429760,1148965219,'Sending template \'participant_reminder2\' email about \'Reminder 2: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,'88B3AB609C4',NULL),(6,3,'escalation','escalate',1,1,1,'[%execemail%]',1147220187,1148516160,1148965220,'Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,'825E9B606C0',NULL),(7,4,'reminder3 first go','participant_reminder3',1,1,0,NULL,1147220187,1149034560,1149120241,'Sending template \'participant_reminder3\' email about \'Reminder 3: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,'798B23D3227',NULL),(8,4,'escalation','escalate',1,1,1,'[%execemail%]',1147220160,1149120960,1149207152,'Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'','3C041F2AC3',NULL),(22,14,'invite','peer',1,1,0,NULL,1148967783,1148967780,1148968013,NULL,'MAP010 \'peer\' HTML Substitution problem with \'PEERFIRSTNAME\' \'PEERFULLNAME\'',NULL,NULL),(23,14,'escalate','peer_escalate',1,1,1,'[%execemail%]',1148967783,1149054180,1149120242,'Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,'D9874B668C6',NULL),(24,15,'reminder1','peer_reminder1',1,1,0,NULL,1148967784,1149572580,1149827016,'Sending template \'peer_reminder1\' email about \'Reminder: MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,'C8F22F1012',NULL),(25,15,'escalate','peer_escalate',1,1,1,'[%execemail%]',1148967784,1149658980,1149827019,'Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,'3DF497625B0',NULL),(26,16,'reminder2','peer_reminder2',1,1,0,NULL,1148967784,1150177380,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(27,16,'escalate','peer_escalate',1,1,1,'[%execemail%]',1148967784,1150263780,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(28,17,'reminder3','peer_reminder3',1,1,0,NULL,1148967784,1150782180,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(29,17,'escalate','peer_escalate',1,1,1,'[%execemail%]',1148967784,1150868580,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(30,18,'invite','peer',1,1,0,NULL,1149120039,1149120000,1149120246,'Sending template \'peer\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,'0A0B7F2119',NULL),(31,18,'escalate','peer_escalate',1,1,1,'[%execemail%]',1149120039,1149206400,1149207153,'Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,'437D43C2E9E',NULL),(32,19,'reminder1','peer_reminder1',1,1,0,NULL,1149120039,1149724800,1149827020,'Sending template \'peer_reminder1\' email about \'Reminder: MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,'4ECB43D00A9',NULL),(33,19,'escalate','peer_escalate',1,1,1,'[%execemail%]',1149120039,1149811200,1149827021,'Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,'5BE7911D4EA',NULL),(34,20,'reminder2','peer_reminder2',1,1,0,NULL,1149120039,1150329600,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(35,20,'escalate','peer_escalate',1,1,1,'[%execemail%]',1149120039,1150416000,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(36,21,'reminder3','peer_reminder3',1,1,0,NULL,1149120039,1150934400,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(37,21,'escalate','peer_escalate',1,1,1,'[%execemail%]',1149120039,1151020800,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(38,22,'invite first go','participant',1,1,0,NULL,1149826821,1149826800,1149827021,NULL,'Invalid \'from_email\' email address \'e@m\' supplied to send_process()',NULL,NULL),(39,22,'escalation','escalate',1,1,1,'[%execemail%]',1149826821,1149913200,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(40,23,'reminder1 first go','participant_reminder1',1,1,0,NULL,1149826821,1150431600,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(41,23,'escalation','escalate',1,1,1,'[%execemail%]',1149826821,1150518000,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(42,24,'reminder2 first go','participant_reminder2',1,1,0,NULL,1149826821,1151036400,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(43,24,'escalation','escalate',1,1,1,'[%execemail%]',1149826821,1151122800,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(44,25,'reminder3 first go','participant_reminder3',1,1,0,NULL,1149826821,1151641200,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(45,25,'escalation','escalate',1,1,1,'[%execemail%]',1149826821,1151727600,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(46,26,'invite first go','participant',1,1,0,NULL,1149827138,1149827100,1149827144,'Sending template \'participant\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Randy Gray <ac@market-research.com> : OK',NULL,'EAC9E11D435',NULL),(47,26,'escalation','escalate',1,1,1,'[%execemail%]',1149827138,1149913500,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(48,27,'reminder1 first go','participant_reminder1',1,1,0,NULL,1149827138,1150431900,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(49,27,'escalation','escalate',1,1,1,'[%execemail%]',1149827138,1150518300,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(50,28,'reminder2 first go','participant_reminder2',1,1,0,NULL,1149827138,1151036700,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(51,28,'escalation','escalate',1,1,1,'[%execemail%]',1149827138,1151123100,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(52,29,'reminder3 first go','participant_reminder3',1,1,0,NULL,1149827138,1151641500,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(53,29,'escalation','escalate',1,1,1,'[%execemail%]',1149827138,1151727900,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(54,30,'invite first go','participant',1,1,0,NULL,1149827768,1149827760,1149827808,'Sending template \'participant\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Craig Snyder <mikkel@market-research.com> : OK',NULL,'1B70FB61CB2',NULL),(55,30,'escalation','escalate',1,1,1,'[%execemail%]',1149827768,1149914160,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(56,31,'reminder1 first go','participant_reminder1',1,1,0,NULL,1149827768,1150432560,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(57,31,'escalation','escalate',1,1,1,'[%execemail%]',1149827768,1150518960,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(58,32,'reminder2 first go','participant_reminder2',1,1,0,NULL,1149827768,1151037360,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(59,32,'escalation','escalate',1,1,1,'[%execemail%]',1149827768,1151123760,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(60,33,'reminder3 first go','participant_reminder3',1,1,0,NULL,1149827768,1151642160,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(61,33,'escalation','escalate',1,1,1,'[%execemail%]',1149827768,1151728560,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(62,34,'first invite','boss',1,1,0,NULL,1149827768,1149827760,1149827810,'Sending template \'boss\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Mike King <mikkel@market-research.com> : OK',NULL,'6B5247624EE',NULL),(63,35,'first reminder 1','boss_reminder1',1,1,0,NULL,1149827768,1150432560,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(64,36,'first reminder2','boss_reminder2',1,1,0,NULL,1149827768,1151037360,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(65,37,'first reminder3','boss_reminder3',1,1,0,NULL,1149827768,1151642160,1323599822,'Scheduled before \'Fri Dec  9 21:37:02 2011\'. Not sending',NULL,NULL,NULL),(66,38,'invite','peer',1,1,0,NULL,1327277740,1327277740,1327277764,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Mike King\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(67,38,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1327364140,NULL,NULL,NULL,NULL,NULL),(68,39,'reminder1','peer_reminder1',1,1,0,NULL,1327277740,1327882540,1327882561,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder1.hdr\'',NULL,NULL),(69,39,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1327968940,1327968962,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(70,40,'reminder2','peer_reminder2',1,1,0,NULL,1327277740,1328487340,1328570328,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder2.hdr\'',NULL,NULL),(71,40,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1328573740,1328574197,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(72,41,'reminder3','peer_reminder3',1,1,0,NULL,1327277740,1329092140,1329092162,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder3.hdr\'',NULL,NULL),(73,41,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1329178540,1329178562,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(74,42,'invite','peer',1,1,0,NULL,1327277740,1327277740,1327277763,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Mor Kel\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(75,42,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1327364140,NULL,NULL,NULL,NULL,NULL),(76,43,'reminder1','peer_reminder1',1,1,0,NULL,1327277740,1327882540,1327882561,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder1.hdr\'',NULL,NULL),(77,43,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1327968940,1327968962,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(78,44,'reminder2','peer_reminder2',1,1,0,NULL,1327277740,1328487340,1328570328,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder2.hdr\'',NULL,NULL),(79,44,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1328573740,1328574197,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(80,45,'reminder3','peer_reminder3',1,1,0,NULL,1327277740,1329092140,1329092162,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_reminder3.hdr\'',NULL,NULL),(81,45,'escalate','peer_escalate',1,1,1,'[%execemail%]',1327277740,1329178540,1329178562,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP010/etemplate/peer_escalate.hdr\'',NULL,NULL),(82,46,'invite first go','participant',1,1,0,NULL,1328569979,1328569979,1328570332,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(83,46,'escalation','escalate',1,1,1,'[%execemail%]',1328569979,1328656379,NULL,NULL,NULL,NULL,NULL),(84,47,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328569979,1329174779,1329174782,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(85,47,'escalation','escalate',1,1,1,'[%execemail%]',1328569979,1329261179,1329261182,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(86,48,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328569979,1329779579,1329779582,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(87,48,'escalation','escalate',1,1,1,'[%execemail%]',1328569979,1329865979,1329865981,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(88,49,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328569979,1330384379,1330384382,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(89,49,'escalation','escalate',1,1,1,'[%execemail%]',1328569979,1330470779,1330470781,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(90,50,'execinvite','execinvite',1,1,0,NULL,1328569979,1328569979,1328570331,'Sending template \'execinvite\' email about \'PWI EMAIL: Andrew Creer has been emailed\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(91,51,'first invite','boss',1,1,0,NULL,1328569979,1328569979,1328570330,'Sending template \'boss\' email about \'MAP Workshop Materials\' to \"Boss Bossman\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(92,52,'first reminder 1','boss_reminder1',1,1,0,NULL,1328569979,1329174779,1329174782,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP011/etemplate/boss_reminder1.hdr\'',NULL,NULL),(93,53,'first reminder2','boss_reminder2',1,1,0,NULL,1328569979,1329779579,1329779581,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP011/etemplate/boss_reminder2.hdr\'',NULL,NULL),(94,54,'first reminder3','boss_reminder3',1,1,0,NULL,1328569979,1330384379,1330384382,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP011/etemplate/boss_reminder3.hdr\'',NULL,NULL),(95,55,'invite first go','participant',1,1,0,NULL,1328570111,1328570111,1328570333,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(96,55,'escalation','escalate',1,1,1,'[%execemail%]',1328570111,1328656511,NULL,NULL,NULL,NULL,NULL),(97,56,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328570111,1329174911,1329174961,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(98,56,'escalation','escalate',1,1,1,'[%execemail%]',1328570111,1329261311,1329261362,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(99,57,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328570111,1329779711,1329779762,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(100,57,'escalation','escalate',1,1,1,'[%execemail%]',1328570111,1329866111,1329866161,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(101,58,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328570111,1330384511,1330384562,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(102,58,'escalation','escalate',1,1,1,'[%execemail%]',1328570111,1330470911,1330470961,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(103,59,'invite first go','participant',1,1,0,NULL,1328570139,1328570139,1328570333,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(104,59,'escalation','escalate',1,1,1,'[%execemail%]',1328570139,1328656539,1328829962,'Scheduled before \'Wed Feb  8 10:26:02 2012\'. Not sending',NULL,NULL,NULL),(105,60,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328570139,1329174939,1329174962,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(106,60,'escalation','escalate',1,1,1,'[%execemail%]',1328570139,1329261339,1329261362,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(107,61,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328570139,1329779739,1329779762,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(108,61,'escalation','escalate',1,1,1,'[%execemail%]',1328570139,1329866139,1329866161,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(109,62,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328570139,1330384539,1330384562,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(110,62,'escalation','escalate',1,1,1,'[%execemail%]',1328570139,1330470939,1330470961,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(111,63,'invite first go','participant',1,1,0,NULL,1328570237,1328570237,1328570335,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(112,63,'escalation','escalate',1,1,1,'[%execemail%]',1328570237,1328656637,1328829962,'Scheduled before \'Wed Feb  8 10:26:02 2012\'. Not sending',NULL,NULL,NULL),(113,64,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328570237,1329175037,1329175082,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(114,64,'escalation','escalate',1,1,1,'[%execemail%]',1328570237,1329261437,1329261482,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(115,65,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328570237,1329779837,1329779882,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(116,65,'escalation','escalate',1,1,1,'[%execemail%]',1328570237,1329866237,1329866282,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(117,66,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328570237,1330384637,1330384681,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(118,66,'escalation','escalate',1,1,1,'[%execemail%]',1328570237,1330471037,1330471082,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(119,67,'invite first go','participant',1,1,0,NULL,1328570698,1328570698,1328570704,NULL,'Could not close multipart:Connection not established',NULL,NULL),(120,67,'escalation','escalate',1,1,1,'[%execemail%]',1328570698,1328657098,1328829962,'Scheduled before \'Wed Feb  8 10:26:02 2012\'. Not sending',NULL,NULL,NULL),(121,68,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328570698,1329175498,1329175502,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(122,68,'escalation','escalate',1,1,1,'[%execemail%]',1328570698,1329261898,1329261902,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(123,69,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328570698,1329780298,1329780302,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(124,69,'escalation','escalate',1,1,1,'[%execemail%]',1328570698,1329866698,1329866701,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(125,70,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328570698,1330385098,1330385102,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(126,70,'escalation','escalate',1,1,1,'[%execemail%]',1328570698,1330471498,1330471501,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(127,71,'invite first go','participant',1,1,0,NULL,1328571814,1328571814,1328571820,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'>> 250 2.6.0  <20120206_234338_095054.ac@market-research.com> Queued mail for delivery\r',NULL),(128,71,'escalation','escalate',1,1,1,'[%execemail%]',1328571814,1328658214,NULL,NULL,NULL,NULL,NULL),(129,72,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328571814,1329176614,1329176641,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(130,72,'escalation','escalate',1,1,1,'[%execemail%]',1328571814,1329263014,1329263041,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(131,73,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328571814,1329781414,1329781442,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(132,73,'escalation','escalate',1,1,1,'[%execemail%]',1328571814,1329867814,1329867842,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(133,74,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328571814,1330386214,1330386242,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(134,74,'escalation','escalate',1,1,1,'[%execemail%]',1328571814,1330472614,1330472641,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(135,75,'invite first go','participant',1,1,0,NULL,1328574191,1328574191,1328574198,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'1',NULL),(136,75,'escalation','escalate',1,1,1,'[%execemail%]',1328574191,1328660591,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(137,76,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328574191,1329178991,1329179041,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(138,76,'escalation','escalate',1,1,1,'[%execemail%]',1328574191,1329265391,1329265442,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(139,77,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328574191,1329783791,1329783842,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(140,77,'escalation','escalate',1,1,1,'[%execemail%]',1328574191,1329870191,1329870242,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(141,78,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328574191,1330388591,1330388642,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(142,78,'escalation','escalate',1,1,1,'[%execemail%]',1328574191,1330474991,1330475042,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(143,79,'invite first go','participant',1,1,0,NULL,1328574604,1328574604,1328574610,NULL,'Could not close multipart:Transmission of message failed (4.3.0 collect: Cannot write ./dfq170UAOe021457 (sm_io_flush||sm_io_error, uid=0, gid=126): Input/output error\r)',NULL,NULL),(144,79,'escalation','escalate',1,1,1,'[%execemail%]',1328574604,1328661004,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(145,80,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328574604,1329179404,1329179462,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(146,80,'escalation','escalate',1,1,1,'[%execemail%]',1328574604,1329265804,1329265861,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(147,81,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328574604,1329784204,1329784262,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(148,81,'escalation','escalate',1,1,1,'[%execemail%]',1328574604,1329870604,1329870661,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(149,82,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328574604,1330389004,1330389061,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(150,82,'escalation','escalate',1,1,1,'[%execemail%]',1328574604,1330475404,1330475462,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(151,83,'invite first go','participant',1,1,0,NULL,1328574659,1328574659,1328574668,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkel@market-research.com> : OK',NULL,'>> 250 2.6.0  <20120207_003106_018189.ac@market-research.com> Queued mail for delivery\r',NULL),(152,83,'escalation','escalate',1,1,1,'[%execemail%]',1328574659,1328661059,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(153,84,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328574659,1329179459,1329179462,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(154,84,'escalation','escalate',1,1,1,'[%execemail%]',1328574659,1329265859,1329265861,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(155,85,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328574659,1329784259,1329784262,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(156,85,'escalation','escalate',1,1,1,'[%execemail%]',1328574659,1329870659,1329870661,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(157,86,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328574659,1330389059,1330389061,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(158,86,'escalation','escalate',1,1,1,'[%execemail%]',1328574659,1330475459,1330475462,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(159,87,'invite first go','participant',1,1,0,NULL,1328575011,1328575011,1328577587,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(160,87,'escalation','escalate',1,1,1,'[%execemail%]',1328575011,1328661411,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(161,88,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328575011,1329179811,1329179822,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(162,88,'escalation','escalate',1,1,1,'[%execemail%]',1328575011,1329266211,1329266221,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(163,89,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328575011,1329784611,1329784622,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(164,89,'escalation','escalate',1,1,1,'[%execemail%]',1328575011,1329871011,1329871021,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(165,90,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328575011,1330389411,1330389421,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(166,90,'escalation','escalate',1,1,1,'[%execemail%]',1328575011,1330475811,1330475821,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(167,91,'invite first go','participant',1,1,0,NULL,1328575331,1328575331,1328577588,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(168,91,'escalation','escalate',1,1,1,'[%execemail%]',1328575331,1328661731,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(169,92,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328575331,1329180131,1329180182,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(170,92,'escalation','escalate',1,1,1,'[%execemail%]',1328575331,1329266531,1329266582,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(171,93,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328575331,1329784931,1329784982,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(172,93,'escalation','escalate',1,1,1,'[%execemail%]',1328575331,1329871331,1329871381,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(173,94,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328575331,1330389731,1330389781,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(174,94,'escalation','escalate',1,1,1,'[%execemail%]',1328575331,1330476131,1330476182,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(175,95,'execinvite','execinvite',1,1,0,NULL,1328575331,1328575331,1328577587,'Sending template \'execinvite\' email about \'PWI EMAIL: Andrew Creer has been emailed\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(176,96,'invite first go','participant',1,1,0,NULL,1328577728,1328577728,1328577729,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(177,96,'escalation','escalate',1,1,1,'[%execemail%]',1328577728,1328664128,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(178,97,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328577728,1329182528,1329182581,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(179,97,'escalation','escalate',1,1,1,'[%execemail%]',1328577728,1329268928,1329268982,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(180,98,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328577728,1329787328,1329787382,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(181,98,'escalation','escalate',1,1,1,'[%execemail%]',1328577728,1329873728,1329873782,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(182,99,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328577728,1330392128,1330392182,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(183,99,'escalation','escalate',1,1,1,'[%execemail%]',1328577728,1330478528,1330478582,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(184,100,'invite first go','participant',1,1,0,NULL,1328577960,1328577960,1328579397,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'>> 250 2.6.0  <20120207_014956_000689.ac@market-research.com> Queued mail for delivery\r',NULL),(185,100,'escalation','escalate',1,1,1,'[%execemail%]',1328577960,1328664360,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(186,101,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328577960,1329182760,1329182762,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(187,101,'escalation','escalate',1,1,1,'[%execemail%]',1328577960,1329269160,1329269162,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(188,102,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328577960,1329787560,1329787562,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(189,102,'escalation','escalate',1,1,1,'[%execemail%]',1328577960,1329873960,1329873962,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(190,103,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328577960,1330392360,1330392362,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(191,103,'escalation','escalate',1,1,1,'[%execemail%]',1328577960,1330478760,1330478762,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(192,104,'invite first go','participant',1,1,0,NULL,1328579395,1328579395,1328579489,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(193,104,'escalation','escalate',1,1,1,'[%execemail%]',1328579395,1328665795,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(194,105,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328579395,1329184195,1329184202,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(195,105,'escalation','escalate',1,1,1,'[%execemail%]',1328579395,1329270595,1329270602,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(196,106,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328579395,1329788995,1329789002,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(197,106,'escalation','escalate',1,1,1,'[%execemail%]',1328579395,1329875395,1329875402,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(198,107,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328579395,1330393795,1330393802,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(199,107,'escalation','escalate',1,1,1,'[%execemail%]',1328579395,1330480195,1330480202,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(200,108,'invite first go','participant',1,1,0,NULL,1328579488,1328579488,1328579489,'Sending template \'participant\' email about \'MAP Workshop Materials\' to \"Andrew Creer\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(201,108,'escalation','escalate',1,1,1,'[%execemail%]',1328579488,1328665888,1328829963,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(202,109,'reminder1 first go','participant_reminder1',1,1,0,NULL,1328579488,1329184288,1329184322,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder1.hdr\'',NULL,NULL),(203,109,'escalation','escalate',1,1,1,'[%execemail%]',1328579488,1329270688,1329270722,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(204,110,'reminder2 first go','participant_reminder2',1,1,0,NULL,1328579488,1329789088,1329789121,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder2.hdr\'',NULL,NULL),(205,110,'escalation','escalate',1,1,1,'[%execemail%]',1328579488,1329875488,1329875521,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(206,111,'reminder3 first go','participant_reminder3',1,1,0,NULL,1328579488,1330393888,1330393921,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/participant_reminder3.hdr\'',NULL,NULL),(207,111,'escalation','escalate',1,1,1,'[%execemail%]',1328579488,1330480288,1330480321,NULL,'Header file does not exist \'/home/vhosts/pwidev/triton/MAP001/etemplate/escalate.hdr\'',NULL,NULL),(208,112,'invite','peer',1,1,0,NULL,1334140916,1334140916,1334140922,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Mikkel Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(209,112,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334140916,1334227316,NULL,NULL,NULL,NULL,NULL),(210,113,'reminder1','peer_reminder1',1,1,0,NULL,1334140916,1334745716,NULL,NULL,NULL,NULL,NULL),(211,113,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334140916,1334832116,NULL,NULL,NULL,NULL,NULL),(212,114,'reminder2','peer_reminder2',1,1,0,NULL,1334140916,1335350516,NULL,NULL,NULL,NULL,NULL),(213,114,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334140916,1335436916,NULL,NULL,NULL,NULL,NULL),(214,115,'reminder3','peer_reminder3',1,1,0,NULL,1334140916,1335955316,NULL,NULL,NULL,NULL,NULL),(215,115,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334140916,1336041716,NULL,NULL,NULL,NULL,NULL),(216,116,'invite','peer',1,1,0,NULL,1334186793,1334186793,1334186822,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Fok Mee Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(217,116,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334186793,1334273193,NULL,NULL,NULL,NULL,NULL),(218,117,'reminder1','peer_reminder1',1,1,0,NULL,1334186793,1334791593,NULL,NULL,NULL,NULL,NULL),(219,117,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334186793,1334877993,NULL,NULL,NULL,NULL,NULL),(220,118,'reminder2','peer_reminder2',1,1,0,NULL,1334186793,1335396393,NULL,NULL,NULL,NULL,NULL),(221,118,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334186793,1335482793,NULL,NULL,NULL,NULL,NULL),(222,119,'reminder3','peer_reminder3',1,1,0,NULL,1334186793,1336001193,NULL,NULL,NULL,NULL,NULL),(223,119,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334186793,1336087593,NULL,NULL,NULL,NULL,NULL),(224,120,'invite','peer',1,1,0,NULL,1334188015,1334188015,1334188022,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Fok Mee Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(225,120,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188015,1334274415,1334274421,NULL,'No record in MAP010 job table for pwd ARTBDSTG',NULL,NULL),(226,121,'reminder1','peer_reminder1',1,1,0,NULL,1334188015,1334792815,NULL,NULL,NULL,NULL,NULL),(227,121,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188015,1334879215,NULL,NULL,NULL,NULL,NULL),(228,122,'reminder2','peer_reminder2',1,1,0,NULL,1334188015,1335397615,NULL,NULL,NULL,NULL,NULL),(229,122,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188015,1335484015,NULL,NULL,NULL,NULL,NULL),(230,123,'reminder3','peer_reminder3',1,1,0,NULL,1334188015,1336002415,NULL,NULL,NULL,NULL,NULL),(231,123,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188015,1336088815,NULL,NULL,NULL,NULL,NULL),(232,124,'invite','peer',1,1,0,NULL,1334188125,1334188125,1334188142,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Fok Mee Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(233,124,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188125,1334274525,1334274542,NULL,'No record in MAP010 job table for pwd ARTBDSTG',NULL,NULL),(234,125,'reminder1','peer_reminder1',1,1,0,NULL,1334188125,1334792925,NULL,NULL,NULL,NULL,NULL),(235,125,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188125,1334879325,NULL,NULL,NULL,NULL,NULL),(236,126,'reminder2','peer_reminder2',1,1,0,NULL,1334188125,1335397725,NULL,NULL,NULL,NULL,NULL),(237,126,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188125,1335484125,NULL,NULL,NULL,NULL,NULL),(238,127,'reminder3','peer_reminder3',1,1,0,NULL,1334188125,1336002525,NULL,NULL,NULL,NULL,NULL),(239,127,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188125,1336088925,NULL,NULL,NULL,NULL,NULL),(240,128,'invite','peer',1,1,0,NULL,1334188149,1334188149,1334188202,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Fok Mee Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(241,128,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188149,1334274549,1334274602,NULL,'No record in MAP010 job table for pwd ARTBDSTG',NULL,NULL),(242,129,'reminder1','peer_reminder1',1,1,0,NULL,1334188149,1334792949,NULL,NULL,NULL,NULL,NULL),(243,129,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188149,1334879349,NULL,NULL,NULL,NULL,NULL),(244,130,'reminder2','peer_reminder2',1,1,0,NULL,1334188149,1335397749,NULL,NULL,NULL,NULL,NULL),(245,130,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188149,1335484149,NULL,NULL,NULL,NULL,NULL),(246,131,'reminder3','peer_reminder3',1,1,0,NULL,1334188149,1336002549,NULL,NULL,NULL,NULL,NULL),(247,131,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188149,1336088949,NULL,NULL,NULL,NULL,NULL),(248,132,'invite','peer',1,1,0,NULL,1334188278,1334188278,1334188322,'Sending template \'peer\' email about \'MAP Workshop Materials\' to \"Fok Mee Wong\" <mikkelking@hotmail.com> : OK',NULL,'1',NULL),(249,132,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188278,1334274678,NULL,NULL,NULL,NULL,NULL),(250,133,'reminder1','peer_reminder1',1,1,0,NULL,1334188278,1334793078,NULL,NULL,NULL,NULL,NULL),(251,133,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188278,1334879478,NULL,NULL,NULL,NULL,NULL),(252,134,'reminder2','peer_reminder2',1,1,0,NULL,1334188278,1335397878,NULL,NULL,NULL,NULL,NULL),(253,134,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188278,1335484278,NULL,NULL,NULL,NULL,NULL),(254,135,'reminder3','peer_reminder3',1,1,0,NULL,1334188278,1336002678,NULL,NULL,NULL,NULL,NULL),(255,135,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334188278,1336089078,NULL,NULL,NULL,NULL,NULL),(256,136,'invite','peer',1,1,0,NULL,1334264187,1334264187,1334264222,NULL,'No record in MAP010 job table for pwd ARTBDSTG',NULL,NULL),(257,136,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334264187,1334350587,1334350621,NULL,'No record in MAP010 job table for pwd ARTBDSTG',NULL,NULL),(258,137,'reminder1','peer_reminder1',1,1,0,NULL,1334264187,1334868987,NULL,NULL,NULL,NULL,NULL),(259,137,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334264187,1334955387,NULL,NULL,NULL,NULL,NULL),(260,138,'reminder2','peer_reminder2',1,1,0,NULL,1334264187,1335473787,NULL,NULL,NULL,NULL,NULL),(261,138,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334264187,1335560187,NULL,NULL,NULL,NULL,NULL),(262,139,'reminder3','peer_reminder3',1,1,0,NULL,1334264187,1336078587,NULL,NULL,NULL,NULL,NULL),(263,139,'escalate','peer_escalate',1,1,1,'[%execemail%]',1334264187,1336164987,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `EMAIL_MSG_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_SCHEME`
--

DROP TABLE IF EXISTS `EMAIL_SCHEME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_SCHEME` (
  `EMAIL_SCHEME_ID` int(11) NOT NULL,
  `SCHEME_NAME` varchar(100) NOT NULL,
  `SID` varchar(12) NOT NULL,
  PRIMARY KEY (`EMAIL_SCHEME_ID`),
  UNIQUE KEY `SID` (`SID`,`SCHEME_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_SCHEME`
--

LOCK TABLES `EMAIL_SCHEME` WRITE;
/*!40000 ALTER TABLE `EMAIL_SCHEME` DISABLE KEYS */;
INSERT INTO `EMAIL_SCHEME` VALUES (1,'peer','MAP010'),(2,'participant','MAP001'),(3,'boss','MAP011'),(4,'execstart','MAP001'),(5,'execinvite','MAP001');
/*!40000 ALTER TABLE `EMAIL_SCHEME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_SCHEME_STATUS`
--

DROP TABLE IF EXISTS `EMAIL_SCHEME_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_SCHEME_STATUS` (
  `EMAIL_SCHEME_STATUS_ID` int(11) NOT NULL,
  `SCHEME_STATUS_NAME` varchar(100) NOT NULL,
  `CREATED_EPOCH` int(11) NOT NULL,
  `SID` varchar(12) NOT NULL,
  `PWD` varchar(12) NOT NULL,
  `LANGUAGE` varchar(2) DEFAULT NULL,
  `SCHEME_DONE_EPOCH` int(11) DEFAULT NULL,
  `SCHEME_ACTIVE_FLAG` int(11) NOT NULL DEFAULT '1',
  `EMAIL_SCHEME_ID` int(11) NOT NULL,
  PRIMARY KEY (`EMAIL_SCHEME_STATUS_ID`),
  KEY `EMAIL_SCHEME_ID` (`EMAIL_SCHEME_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_SCHEME_STATUS`
--

LOCK TABLES `EMAIL_SCHEME_STATUS` WRITE;
/*!40000 ALTER TABLE `EMAIL_SCHEME_STATUS` DISABLE KEYS */;
INSERT INTO `EMAIL_SCHEME_STATUS` VALUES (4,'participant',1147220310,'MAP001','YEGSTCDK',NULL,NULL,0,2),(1,'participant',1147220187,'MAP001','YEGSTCDK',NULL,NULL,1,2),(2,'execinvite',1147220187,'MAP001','YEGSTCDK',NULL,NULL,1,5),(3,'boss',1147220187,'MAP011','YNYCPYUG',NULL,NULL,1,3),(5,'peer',1148967783,'MAP010','FBEUPSDH',NULL,NULL,1,1),(6,'peer',1149120039,'MAP010','FBEUPSDH',NULL,NULL,1,1),(7,'participant',1149826820,'MAP001','ZHRYBRHT',NULL,NULL,1,2),(8,'participant',1149827138,'MAP001','ZGDUBGMT',NULL,NULL,1,2),(9,'execstart',1149827599,'MAP001','ZGDUBGMT',NULL,NULL,1,4),(10,'participant',1149827768,'MAP001','ZHRYBRHT',NULL,NULL,1,2),(11,'boss',1149827768,'MAP011','MBMXURDZ',NULL,NULL,1,3),(12,'execstart',1149828050,'MAP001','ZHRYBRHT',NULL,NULL,1,4),(13,'execstart',1326149343,'MAP001','YEGSTCDK',NULL,NULL,1,4),(14,'peer',1327277740,'MAP010','FBEUPSDH',NULL,NULL,1,1),(15,'peer',1327277740,'MAP010','AEYGAMCP',NULL,NULL,1,1),(16,'participant',1328569979,'MAP001','YEGSTCDK',NULL,NULL,1,2),(17,'execinvite',1328569979,'MAP001','YEGSTCDK',NULL,NULL,1,5),(18,'boss',1328569979,'MAP011','YNYCPYUG',NULL,NULL,1,3),(19,'participant',1328570111,'MAP001','YEGSTCDK',NULL,NULL,1,2),(20,'participant',1328570139,'MAP001','YEGSTCDK',NULL,NULL,1,2),(21,'participant',1328570237,'MAP001','YEGSTCDK',NULL,NULL,1,2),(22,'participant',1328570698,'MAP001','YEGSTCDK',NULL,NULL,1,2),(23,'participant',1328571814,'MAP001','YEGSTCDK',NULL,NULL,1,2),(24,'participant',1328574191,'MAP001','YEGSTCDK',NULL,NULL,1,2),(25,'participant',1328574604,'MAP001','YEGSTCDK',NULL,NULL,1,2),(26,'participant',1328574659,'MAP001','YEGSTCDK',NULL,NULL,1,2),(27,'participant',1328575011,'MAP001','YEGSTCDK',NULL,NULL,1,2),(28,'participant',1328575331,'MAP001','YEGSTCDK',NULL,NULL,1,2),(29,'execinvite',1328575331,'MAP001','YEGSTCDK',NULL,NULL,1,5),(30,'participant',1328577728,'MAP001','YEGSTCDK',NULL,NULL,1,2),(31,'participant',1328577960,'MAP001','YEGSTCDK',NULL,NULL,1,2),(32,'participant',1328579395,'MAP001','YEGSTCDK',NULL,NULL,1,2),(33,'participant',1328579488,'MAP001','YEGSTCDK',NULL,NULL,1,2),(34,'execstart',1333503071,'MAP001','XBGEPMDN',NULL,NULL,1,4),(35,'peer',1334140916,'MAP010','REXKYGTB',NULL,NULL,1,1),(36,'peer',1334186793,'MAP010','ARTBDSTG',NULL,NULL,1,1),(37,'peer',1334188015,'MAP010','ARTBDSTG',NULL,NULL,1,1),(38,'peer',1334188125,'MAP010','ARTBDSTG',NULL,NULL,1,1),(39,'peer',1334188149,'MAP010','ARTBDSTG',NULL,NULL,1,1),(40,'peer',1334188278,'MAP010','ARTBDSTG',NULL,NULL,1,1),(41,'peer',1334264187,'MAP010','ARTBDSTG',NULL,NULL,1,1);
/*!40000 ALTER TABLE `EMAIL_SCHEME_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_TRACK`
--

DROP TABLE IF EXISTS `EMAIL_TRACK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_TRACK` (
  `EMAIL_TRACK_ID` int(11) NOT NULL,
  `EMAIL_SCHEME_ID` int(11) NOT NULL,
  `TRACK_NAME` varchar(100) NOT NULL,
  `TRACK_INTERVAL` int(11) NOT NULL,
  PRIMARY KEY (`EMAIL_TRACK_ID`),
  KEY `EMAIL_SCHEME_ID` (`EMAIL_SCHEME_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_TRACK`
--

LOCK TABLES `EMAIL_TRACK` WRITE;
/*!40000 ALTER TABLE `EMAIL_TRACK` DISABLE KEYS */;
INSERT INTO `EMAIL_TRACK` VALUES (1,1,'Invite1',0),(2,1,'Reminder1',604800),(3,1,'Reminder2',1209600),(5,2,'Invite1',0),(6,2,'Reminder1',604800),(7,2,'Reminder2',1209600),(4,1,'Reminder3',1814400),(9,5,'execinvite',0),(10,3,'Invite1',0),(11,3,'Reminder1',604800),(8,2,'Reminder3',1814400),(12,3,'Reminder2',1209600),(13,3,'reminder3',1814400);
/*!40000 ALTER TABLE `EMAIL_TRACK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_TRACK_STATUS`
--

DROP TABLE IF EXISTS `EMAIL_TRACK_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_TRACK_STATUS` (
  `EMAIL_TRACK_STATUS_ID` int(11) NOT NULL,
  `EMAIL_SCHEME_STATUS_ID` int(11) NOT NULL,
  `TRACK_STATUS_NAME` varchar(100) NOT NULL,
  `TRACK_INTERVAL` int(11) NOT NULL,
  `CREATED_EPOCH` int(11) NOT NULL,
  `TRACK_READ_FLAG` int(11) DEFAULT '0',
  `TRACK_STOP_FLAG` int(11) DEFAULT '0',
  `TRACK_HOLD_FLAG` int(11) DEFAULT '0',
  PRIMARY KEY (`EMAIL_TRACK_STATUS_ID`),
  KEY `EMAIL_SCHEME_STATUS_ID` (`EMAIL_SCHEME_STATUS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_TRACK_STATUS`
--

LOCK TABLES `EMAIL_TRACK_STATUS` WRITE;
/*!40000 ALTER TABLE `EMAIL_TRACK_STATUS` DISABLE KEYS */;
INSERT INTO `EMAIL_TRACK_STATUS` VALUES (12,4,'Reminder2',1209600,1147220310,0,0,0),(9,3,'reminder3',1814400,1147220187,1,0,0),(10,4,'Invite1',0,1147220310,0,0,0),(11,4,'Reminder1',604800,1147220310,0,0,0),(8,3,'Reminder2',1209600,1147220187,0,0,0),(7,3,'Reminder1',604800,1147220187,0,0,0),(6,3,'Invite1',0,1147220187,1,0,0),(1,1,'Invite1',0,1147220187,0,0,0),(2,1,'Reminder1',604800,1147220187,0,0,0),(3,1,'Reminder2',1209600,1147220187,0,0,0),(4,1,'Reminder3',1814400,1147220187,0,0,0),(5,2,'execinvite',0,1147220187,0,0,0),(13,4,'Reminder3',1814400,1147220311,0,0,0),(14,5,'Invite1',0,1148967783,0,0,0),(15,5,'Reminder1',604800,1148967783,1,0,0),(16,5,'Reminder2',1209600,1148967784,0,0,0),(17,5,'Reminder3',1814400,1148967784,0,0,0),(18,6,'Invite1',0,1149120039,0,0,0),(19,6,'Reminder1',604800,1149120039,0,0,0),(20,6,'Reminder2',1209600,1149120039,0,0,0),(21,6,'Reminder3',1814400,1149120039,0,0,0),(22,7,'Invite1',0,1149826820,0,0,0),(23,7,'Reminder1',604800,1149826821,0,0,0),(24,7,'Reminder2',1209600,1149826821,0,0,0),(25,7,'Reminder3',1814400,1149826821,0,0,0),(26,8,'Invite1',0,1149827138,0,0,0),(27,8,'Reminder1',604800,1149827138,0,0,0),(28,8,'Reminder2',1209600,1149827138,0,0,0),(29,8,'Reminder3',1814400,1149827138,0,0,0),(30,10,'Invite1',0,1149827768,0,0,0),(31,10,'Reminder1',604800,1149827768,0,0,0),(32,10,'Reminder2',1209600,1149827768,0,0,0),(33,10,'Reminder3',1814400,1149827768,0,0,0),(34,11,'Invite1',0,1149827768,0,0,0),(35,11,'Reminder1',604800,1149827768,0,0,0),(36,11,'Reminder2',1209600,1149827768,0,0,0),(37,11,'reminder3',1814400,1149827768,0,0,0),(38,14,'Invite1',0,1327277740,1,0,0),(39,14,'Reminder1',604800,1327277740,0,0,0),(40,14,'Reminder2',1209600,1327277740,0,0,0),(41,14,'Reminder3',1814400,1327277740,0,0,0),(42,15,'Invite1',0,1327277740,1,0,0),(43,15,'Reminder1',604800,1327277740,0,0,0),(44,15,'Reminder2',1209600,1327277740,0,0,0),(45,15,'Reminder3',1814400,1327277740,0,0,0),(46,16,'Invite1',0,1328569979,1,0,0),(47,16,'Reminder1',604800,1328569979,0,0,0),(48,16,'Reminder2',1209600,1328569979,0,0,0),(49,16,'Reminder3',1814400,1328569979,0,0,0),(50,17,'execinvite',0,1328569979,0,0,0),(51,18,'Invite1',0,1328569979,0,0,0),(52,18,'Reminder1',604800,1328569979,0,0,0),(53,18,'Reminder2',1209600,1328569979,0,0,0),(54,18,'reminder3',1814400,1328569979,0,0,0),(55,19,'Invite1',0,1328570111,1,0,0),(56,19,'Reminder1',604800,1328570111,0,0,0),(57,19,'Reminder2',1209600,1328570111,0,0,0),(58,19,'Reminder3',1814400,1328570111,0,0,0),(59,20,'Invite1',0,1328570139,0,0,0),(60,20,'Reminder1',604800,1328570139,0,0,0),(61,20,'Reminder2',1209600,1328570139,0,0,0),(62,20,'Reminder3',1814400,1328570139,0,0,0),(63,21,'Invite1',0,1328570237,0,0,0),(64,21,'Reminder1',604800,1328570237,0,0,0),(65,21,'Reminder2',1209600,1328570237,0,0,0),(66,21,'Reminder3',1814400,1328570237,0,0,0),(67,22,'Invite1',0,1328570698,0,0,0),(68,22,'Reminder1',604800,1328570698,0,0,0),(69,22,'Reminder2',1209600,1328570698,0,0,0),(70,22,'Reminder3',1814400,1328570698,0,0,0),(71,23,'Invite1',0,1328571814,1,0,0),(72,23,'Reminder1',604800,1328571814,0,0,0),(73,23,'Reminder2',1209600,1328571814,0,0,0),(74,23,'Reminder3',1814400,1328571814,0,0,0),(75,24,'Invite1',0,1328574191,0,0,0),(76,24,'Reminder1',604800,1328574191,0,0,0),(77,24,'Reminder2',1209600,1328574191,0,0,0),(78,24,'Reminder3',1814400,1328574191,0,0,0),(79,25,'Invite1',0,1328574604,0,0,0),(80,25,'Reminder1',604800,1328574604,0,0,0),(81,25,'Reminder2',1209600,1328574604,0,0,0),(82,25,'Reminder3',1814400,1328574604,0,0,0),(83,26,'Invite1',0,1328574659,0,0,0),(84,26,'Reminder1',604800,1328574659,0,0,0),(85,26,'Reminder2',1209600,1328574659,0,0,0),(86,26,'Reminder3',1814400,1328574659,0,0,0),(87,27,'Invite1',0,1328575011,0,0,0),(88,27,'Reminder1',604800,1328575011,0,0,0),(89,27,'Reminder2',1209600,1328575011,0,0,0),(90,27,'Reminder3',1814400,1328575011,0,0,0),(91,28,'Invite1',0,1328575331,0,0,0),(92,28,'Reminder1',604800,1328575331,0,0,0),(93,28,'Reminder2',1209600,1328575331,0,0,0),(94,28,'Reminder3',1814400,1328575331,0,0,0),(95,29,'execinvite',0,1328575331,0,0,0),(96,30,'Invite1',0,1328577728,0,0,0),(97,30,'Reminder1',604800,1328577728,0,0,0),(98,30,'Reminder2',1209600,1328577728,0,0,0),(99,30,'Reminder3',1814400,1328577728,0,0,0),(100,31,'Invite1',0,1328577960,0,0,0),(101,31,'Reminder1',604800,1328577960,0,0,0),(102,31,'Reminder2',1209600,1328577960,0,0,0),(103,31,'Reminder3',1814400,1328577960,0,0,0),(104,32,'Invite1',0,1328579395,0,0,0),(105,32,'Reminder1',604800,1328579395,0,0,0),(106,32,'Reminder2',1209600,1328579395,0,0,0),(107,32,'Reminder3',1814400,1328579395,0,0,0),(108,33,'Invite1',0,1328579488,0,0,0),(109,33,'Reminder1',604800,1328579488,0,0,0),(110,33,'Reminder2',1209600,1328579488,0,0,0),(111,33,'Reminder3',1814400,1328579488,0,0,0),(112,35,'Invite1',0,1334140916,1,0,0),(113,35,'Reminder1',604800,1334140916,0,0,0),(114,35,'Reminder2',1209600,1334140916,0,0,0),(115,35,'Reminder3',1814400,1334140916,0,0,0),(116,36,'Invite1',0,1334186793,1,0,0),(117,36,'Reminder1',604800,1334186793,0,0,0),(118,36,'Reminder2',1209600,1334186793,0,0,0),(119,36,'Reminder3',1814400,1334186793,0,0,0),(120,37,'Invite1',0,1334188015,0,0,0),(121,37,'Reminder1',604800,1334188015,0,0,0),(122,37,'Reminder2',1209600,1334188015,0,0,0),(123,37,'Reminder3',1814400,1334188015,0,0,0),(124,38,'Invite1',0,1334188125,0,0,0),(125,38,'Reminder1',604800,1334188125,0,0,0),(126,38,'Reminder2',1209600,1334188125,0,0,0),(127,38,'Reminder3',1814400,1334188125,0,0,0),(128,39,'Invite1',0,1334188149,0,0,0),(129,39,'Reminder1',604800,1334188149,0,0,0),(130,39,'Reminder2',1209600,1334188149,0,0,0),(131,39,'Reminder3',1814400,1334188149,0,0,0),(132,40,'Invite1',0,1334188278,1,0,0),(133,40,'Reminder1',604800,1334188278,0,0,0),(134,40,'Reminder2',1209600,1334188278,0,0,0),(135,40,'Reminder3',1814400,1334188278,0,0,0),(136,41,'Invite1',0,1334264187,0,0,0),(137,41,'Reminder1',604800,1334264187,0,0,0),(138,41,'Reminder2',1209600,1334264187,0,0,0),(139,41,'Reminder3',1814400,1334264187,0,0,0);
/*!40000 ALTER TABLE `EMAIL_TRACK_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMAIL_WORK`
--

DROP TABLE IF EXISTS `EMAIL_WORK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMAIL_WORK` (
  `EWID` int(11) NOT NULL,
  `SID` varchar(12) NOT NULL,
  `WORK_TYPE` int(11) NOT NULL,
  `INSERT_EPOCH` int(11) NOT NULL,
  `BID` int(11) NOT NULL,
  `START_EPOCH` int(11) DEFAULT NULL,
  `END_EPOCH` int(11) DEFAULT NULL,
  `SENT` int(11) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `NAMES_FILE` varchar(100) NOT NULL,
  `PLAIN_TMPLT` varchar(100) DEFAULT NULL,
  `HTML_TMPLT` varchar(100) DEFAULT NULL,
  `PLEASE_STOP` int(11) DEFAULT NULL,
  `IN_PROGRESS` int(11) DEFAULT NULL,
  `PREPARED` int(11) DEFAULT NULL,
  `ERROR` text,
  PRIMARY KEY (`EWID`),
  KEY `BID` (`BID`,`SID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMAIL_WORK`
--

LOCK TABLES `EMAIL_WORK` WRITE;
/*!40000 ALTER TABLE `EMAIL_WORK` DISABLE KEYS */;
/*!40000 ALTER TABLE `EMAIL_WORK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENTLOG`
--

DROP TABLE IF EXISTS `EVENTLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENTLOG` (
  `SID` varchar(12) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENTLOG`
--

LOCK TABLES `EVENTLOG` WRITE;
/*!40000 ALTER TABLE `EVENTLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `EVENTLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_CODES`
--

DROP TABLE IF EXISTS `EVENT_CODES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT_CODES` (
  `EVENT_CODE` int(11) NOT NULL,
  `CONSTANT_NAME` varchar(50) NOT NULL,
  `EVENT_NAME` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `DEF_SORT_ORDER` int(11) DEFAULT NULL,
  PRIMARY KEY (`EVENT_CODE`),
  UNIQUE KEY `CONSTANT_NAME` (`CONSTANT_NAME`),
  UNIQUE KEY `EVENT_NAME` (`EVENT_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_CODES`
--

LOCK TABLES `EVENT_CODES` WRITE;
/*!40000 ALTER TABLE `EVENT_CODES` DISABLE KEYS */;
INSERT INTO `EVENT_CODES` VALUES (0,'UNKNOWN','Unknown','',5),(15,'DELETE_RECIPIENT','Delete Recipient','',10),(17,'PREP_BATCH','Prep Batch','',15),(18,'ADD_RECIPIENT','Add Recipient','',20),(19,'RESET_RECIPIENT','Reset Recipient','',25),(20,'SEND_EMAIL','Send Email','',35),(21,'SEND_REMINDER','Send Reminder','',40),(22,'SEND_FAX','Send Fax','',45),(23,'REJECT_RECIPIENT','Reject Recipient','',50),(24,'PREP_REMINDER','Prep Reminder','',55),(25,'SEND_BATCH','Send Batch','',60),(26,'MAIL_OOO','Mail Ooo','',70),(27,'FAX_DELIVERY','Fax Delivery','',75),(216,'MAIL_BANNER_READ','Mail Banner Read','',80),(28,'MAIL_SERVICE_UNAVAILABLE','Mail Service Unavailable','',85),(29,'MAIL_FORWARD','Mail Forward','',90),(30,'MAIL_UNSUBSCRIBE','Mail Unsubscribe','',95),(31,'MAIL_SPAM','Mail Spam','',100),(32,'MAIL_RETURN','Mail Return','',105),(80,'MAIL_UNDELIVERABLE','Mail Undeliverable','',110),(81,'MAIL_WARNING','Mail Warning','',115),(33,'SURVEY_START','Survey Start','',125),(34,'SURVEY_SAVE','Survey Save','',130),(35,'SURVEY_RESUME','Survey Resume','',135),(36,'SURVEY_FINISH','Survey Finish','',140),(37,'SURVEY_TERMINATE','Survey Terminate','',145),(65,'FILE_UPLOAD','File Upload','',155),(66,'FILE_EXTRA_INFO','File Extra Info','',160),(129,'DB_CREATE_TABLE','Db Create Table','',170),(130,'DB_DROP_TABLE','Db Drop Table','',175),(131,'DB_EMPTY_TABLE','Db Empty Table','',180),(132,'DB_ALTER_TABLE','Db Alter Table','',185);
/*!40000 ALTER TABLE `EVENT_CODES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_VIEW`
--

DROP TABLE IF EXISTS `EVENT_VIEW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT_VIEW` (
  `VIEW_ID` int(11) NOT NULL,
  `VIEW_NAME` varchar(50) NOT NULL,
  PRIMARY KEY (`VIEW_ID`),
  UNIQUE KEY `VIEW_NAME` (`VIEW_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_VIEW`
--

LOCK TABLES `EVENT_VIEW` WRITE;
/*!40000 ALTER TABLE `EVENT_VIEW` DISABLE KEYS */;
INSERT INTO `EVENT_VIEW` VALUES (1,'pwikit');
/*!40000 ALTER TABLE `EVENT_VIEW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_VIEW_LINK`
--

DROP TABLE IF EXISTS `EVENT_VIEW_LINK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT_VIEW_LINK` (
  `VIEW_ID` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SORT_ORDER` int(11) NOT NULL,
  PRIMARY KEY (`VIEW_ID`,`EVENT_CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_VIEW_LINK`
--

LOCK TABLES `EVENT_VIEW_LINK` WRITE;
/*!40000 ALTER TABLE `EVENT_VIEW_LINK` DISABLE KEYS */;
INSERT INTO `EVENT_VIEW_LINK` VALUES (1,20,1),(1,33,5),(1,24,6),(1,23,2),(1,216,3),(1,36,4);
/*!40000 ALTER TABLE `EVENT_VIEW_LINK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JOB`
--

DROP TABLE IF EXISTS `JOB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JOB` (
  `SID` varchar(12) NOT NULL,
  `VID` int(11) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  PRIMARY KEY (`SID`),
  KEY `VID` (`VID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JOB`
--

LOCK TABLES `JOB` WRITE;
/*!40000 ALTER TABLE `JOB` DISABLE KEYS */;
INSERT INTO `JOB` VALUES ('PARTICIPANT',1,'mikkel@market-research.com');
/*!40000 ALTER TABLE `JOB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP001`
--

DROP TABLE IF EXISTS `MAP001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP001` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP001`
--

LOCK TABLES `MAP001` WRITE;
/*!40000 ALTER TABLE `MAP001` DISABLE KEYS */;
INSERT INTO `MAP001` VALUES ('UERYHSMN','731810',4,'Brent Andersen',1313449504,1313449504,1271,0,'Brent.A@thelivingplanet.com',0,1),('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,0),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1293,0,'scott@badgeville.com',0,1),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1314,0,'bconway@airconway.com',0,0);
/*!40000 ALTER TABLE `MAP001` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP001_E`
--

DROP TABLE IF EXISTS `MAP001_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP001_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL,
  `TP` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP001_E`
--

LOCK TABLES `MAP001_E` WRITE;
/*!40000 ALTER TABLE `MAP001_E` DISABLE KEYS */;
INSERT INTO `MAP001_E` VALUES ('MAP001',1148965198,20,'I','system','sendmail:22D6EB609C7 Sending template \'execinvite\' email about \'PWI EMAIL: Andrew Creer has been emailed\' to Andrew Creer <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','Andrew Creer <ac@market-research.com>',2006,5,30,14,59,0),('MAP001',1148965206,20,'I','system','sendmail:5D591F0725 Sending template \'participant\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','Andrew Creer <ac@market-research.com>',2006,5,30,15,0,0),('MAP001',1148965214,20,'I','system','sendmail:7863DF074F Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','andrewcreer@fastmail.fm',2006,5,30,15,0,0),('MAP001',1148965216,20,'I','system','sendmail:318AC760B31 Sending template \'participant_reminder1\' email about \'Reminder: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','Andrew Creer <ac@market-research.com>',2006,5,30,15,0,0),('MAP001',1148965217,20,'I','system','sendmail:30E44761F67 Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','andrewcreer@fastmail.fm',2006,5,30,15,0,0),('MAP001',1148965219,20,'I','system','sendmail:88B3AB609C4 Sending template \'participant_reminder2\' email about \'Reminder 2: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','Andrew Creer <ac@market-research.com>',2006,5,30,15,0,0),('MAP001',1148965220,20,'I','system','sendmail:825E9B606C0 Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','andrewcreer@fastmail.fm',2006,5,30,15,0,0),('MAP001',1149120241,20,'I','system','sendmail:798B23D3227 Sending template \'participant_reminder3\' email about \'Reminder 3: MAP -  May 29, 2006 deadline - MAP Workshop Materials\' to Andrew Creer <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','Andrew Creer <ac@market-research.com>',2006,6,1,10,4,43),('MAP001',1149205981,20,'E','scripts/es','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'',NULL,NULL,NULL,NULL,NULL,NULL,'[%execemail%]',2006,6,2,9,53,67),('MAP001',1149206850,20,'E','scripts/es','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'',NULL,NULL,NULL,NULL,NULL,NULL,'[%execemail%]',2006,6,2,10,7,67),('MAP001',1149206893,20,'E','scripts/es','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'',NULL,NULL,NULL,NULL,NULL,NULL,'[%execemail%]',2006,6,2,10,8,67),('MAP001',1149206983,20,'E','scripts/es','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'',NULL,NULL,NULL,NULL,NULL,NULL,'[%execemail%]',2006,6,2,10,9,67),('MAP001',1149207046,20,'E','scripts/es','MAP001 \'escalate\' PLAIN Substitution problem with \'BOGUS\'',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','[%execemail%]',2006,6,2,10,10,67),('MAP001',1149207152,20,'I','system','sendmail:3C041F2AC3 Sending template \'escalate\' email about \'Escalation Notice\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK','andrewcreer@fastmail.fm',2006,6,2,10,12,67),('MAP001',1149556820,33,'I','system','Fake survey start from AC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2006,6,6,11,20,164),('MAP001',1149556902,33,'I','system','Fake survey start from AC',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,2006,6,6,11,21,164),('MAP001',1149827021,20,'E','system','Invalid \'from_email\' email address \'e@m\' supplied to send_process()',NULL,NULL,NULL,NULL,NULL,'ZHRYBRHT','Craig Snyder <mikkel@market-research.com>',2006,6,9,14,23,NULL),('MAP001',1149557037,36,'I','system','Fake survey start from AC',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,2006,6,6,11,23,NULL),('MAP001',1149827144,20,'I','system','sendmail:EAC9E11D435 Sending template \'participant\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Randy Gray <ac@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'ZGDUBGMT','Randy Gray <ac@market-research.com>',2006,6,9,14,25,NULL),('MAP001',1149827808,20,'I','system','sendmail:1B70FB61CB2 Sending template \'participant\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Craig Snyder <mikkel@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'ZHRYBRHT','Craig Snyder <mikkel@market-research.com>',2006,6,9,14,36,NULL),('MAP001',1329302806,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,21,46,NULL),('MAP001',1329302893,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,21,48,NULL),('MAP001',1329362579,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,14,22,NULL),('MAP001',1329362594,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,14,23,NULL),('MAP001',1329385321,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,42,NULL),('MAP001',1329702840,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,12,54,NULL),('MAP001',1333504365,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,52,NULL);
/*!40000 ALTER TABLE `MAP001_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP002`
--

DROP TABLE IF EXISTS `MAP002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP002` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP002`
--

LOCK TABLES `MAP002` WRITE;
/*!40000 ALTER TABLE `MAP002` DISABLE KEYS */;
INSERT INTO `MAP002` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1294,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1315,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP002` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP002_E`
--

DROP TABLE IF EXISTS `MAP002_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP002_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP002_E`
--

LOCK TABLES `MAP002_E` WRITE;
/*!40000 ALTER TABLE `MAP002_E` DISABLE KEYS */;
INSERT INTO `MAP002_E` VALUES ('MAP002',1323599002,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,11,21,23),('MAP002',1327317749,33,'I','user','Set status=3 for id=717588, pwd=ZHRYBRHT',NULL,NULL,NULL,NULL,NULL,'ZHRYBRHT',NULL,1900,1,23,22,22),('MAP002',1329350911,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,8),('MAP002',1329351261,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,14),('MAP002',1329351276,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,14),('MAP002',1329351393,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,16),('MAP002',1329351605,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,20),('MAP002',1329351687,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,21),('MAP002',1329351702,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,21),('MAP002',1329351708,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,21),('MAP002',1329351715,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,21),('MAP002',1329351745,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,22),('MAP002',1329351860,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,24),('MAP002',1329351869,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,24),('MAP002',1329351874,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,24),('MAP002',1329351888,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,24),('MAP002',1329351894,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,24),('MAP002',1329351911,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,25),('MAP002',1329352046,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,27),('MAP002',1329352567,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,36),('MAP002',1329352585,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,36),('MAP002',1329352590,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,36),('MAP002',1329352671,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,37),('MAP002',1329352990,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,11,43),('MAP002',1329354459,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,12,7),('MAP002',1329354486,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,12,8),('MAP002',1329379688,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,19,8),('MAP002',1329379709,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,19,8),('MAP002',1329702880,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,12,54),('MAP002',1333504537,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,55),('MAP002',1333511175,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,13,46);
/*!40000 ALTER TABLE `MAP002_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP003`
--

DROP TABLE IF EXISTS `MAP003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP003` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP003`
--

LOCK TABLES `MAP003` WRITE;
/*!40000 ALTER TABLE `MAP003` DISABLE KEYS */;
INSERT INTO `MAP003` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1295,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1316,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP003` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP003_E`
--

DROP TABLE IF EXISTS `MAP003_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP003_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP003_E`
--

LOCK TABLES `MAP003_E` WRITE;
/*!40000 ALTER TABLE `MAP003_E` DISABLE KEYS */;
INSERT INTO `MAP003_E` VALUES ('MAP003',1329362894,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,14,28),('MAP003',1329363141,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,14,32),('MAP003',1333504552,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,55);
/*!40000 ALTER TABLE `MAP003_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP004`
--

DROP TABLE IF EXISTS `MAP004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP004` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP004`
--

LOCK TABLES `MAP004` WRITE;
/*!40000 ALTER TABLE `MAP004` DISABLE KEYS */;
INSERT INTO `MAP004` VALUES ('XBGEPMDN','732084',4,'Barbara Bristol',1331118313,1331118313,1001328,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1296,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1317,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP004` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP004_E`
--

DROP TABLE IF EXISTS `MAP004_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP004_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP004_E`
--

LOCK TABLES `MAP004_E` WRITE;
/*!40000 ALTER TABLE `MAP004_E` DISABLE KEYS */;
INSERT INTO `MAP004_E` VALUES ('MAP004',1329304460,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,22,14),('MAP004',1332115861,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,19,11,11),('MAP004',1332115903,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,19,11,11),('MAP004',1332115939,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,19,11,12),('MAP004',1333494507,33,'I','user','Set status=3 for id=732084, pwd=XBGEPMDN',NULL,NULL,NULL,NULL,NULL,'XBGEPMDN',NULL,1900,1,4,9,8),('MAP004',1333494651,36,'I','user','Set status=4 for id=732084, pwd=XBGEPMDN',NULL,NULL,NULL,NULL,NULL,'XBGEPMDN',NULL,1900,1,4,9,10),('MAP004',1333494792,36,'I','user','Set status=4 for id=732084, pwd=XBGEPMDN',NULL,NULL,NULL,NULL,NULL,'XBGEPMDN',NULL,1900,1,4,9,13),('MAP004',1333502422,36,'I','user','Set status=4 for id=732084, pwd=XBGEPMDN',NULL,NULL,NULL,NULL,NULL,'XBGEPMDN',NULL,1900,1,4,11,20),('MAP004',1333504570,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,56);
/*!40000 ALTER TABLE `MAP004_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP005`
--

DROP TABLE IF EXISTS `MAP005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP005` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP005`
--

LOCK TABLES `MAP005` WRITE;
/*!40000 ALTER TABLE `MAP005` DISABLE KEYS */;
INSERT INTO `MAP005` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1297,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1318,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP005` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP005_E`
--

DROP TABLE IF EXISTS `MAP005_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP005_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP005_E`
--

LOCK TABLES `MAP005_E` WRITE;
/*!40000 ALTER TABLE `MAP005_E` DISABLE KEYS */;
INSERT INTO `MAP005_E` VALUES ('MAP005',1329307541,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,23,5),('MAP005',1329308329,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,23,18),('MAP005',1329309954,36,'I','user','Set status=4 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,15,23,45),('MAP005',1329384340,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,25),('MAP005',1333504306,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,51);
/*!40000 ALTER TABLE `MAP005_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP006`
--

DROP TABLE IF EXISTS `MAP006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP006` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP006`
--

LOCK TABLES `MAP006` WRITE;
/*!40000 ALTER TABLE `MAP006` DISABLE KEYS */;
INSERT INTO `MAP006` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1298,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1319,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP006` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP006_E`
--

DROP TABLE IF EXISTS `MAP006_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP006_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP006_E`
--

LOCK TABLES `MAP006_E` WRITE;
/*!40000 ALTER TABLE `MAP006_E` DISABLE KEYS */;
INSERT INTO `MAP006_E` VALUES ('MAP006',1329384400,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,26),('MAP006',1329384524,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,28),('MAP006',1329384532,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,28),('MAP006',1329384553,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,29),('MAP006',1329384596,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,29),('MAP006',1329384605,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,30),('MAP006',1329384653,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,30);
/*!40000 ALTER TABLE `MAP006_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP007`
--

DROP TABLE IF EXISTS `MAP007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP007` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP007`
--

LOCK TABLES `MAP007` WRITE;
/*!40000 ALTER TABLE `MAP007` DISABLE KEYS */;
INSERT INTO `MAP007` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1299,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1320,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP007` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP007_E`
--

DROP TABLE IF EXISTS `MAP007_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP007_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP007_E`
--

LOCK TABLES `MAP007_E` WRITE;
/*!40000 ALTER TABLE `MAP007_E` DISABLE KEYS */;
INSERT INTO `MAP007_E` VALUES ('MAP007',1329384935,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,16,20,35),('MAP007',1333509222,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,13,13),('MAP007',1333513954,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,14,32);
/*!40000 ALTER TABLE `MAP007_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP008`
--

DROP TABLE IF EXISTS `MAP008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP008` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP008`
--

LOCK TABLES `MAP008` WRITE;
/*!40000 ALTER TABLE `MAP008` DISABLE KEYS */;
INSERT INTO `MAP008` VALUES ('','',0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1321,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP008` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP008_E`
--

DROP TABLE IF EXISTS `MAP008_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP008_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP008_E`
--

LOCK TABLES `MAP008_E` WRITE;
/*!40000 ALTER TABLE `MAP008_E` DISABLE KEYS */;
INSERT INTO `MAP008_E` VALUES ('MAP008',1329387012,33,'I','user','Set status=0 for id=, pwd=',NULL,NULL,NULL,NULL,NULL,'',NULL,1900,1,16,21,10),('MAP008',1329705059,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,13,30),('MAP008',1329705089,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,13,31),('MAP008',1329705093,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,13,31),('MAP008',1330595897,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,1,20,58);
/*!40000 ALTER TABLE `MAP008_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP009`
--

DROP TABLE IF EXISTS `MAP009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP009` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP009`
--

LOCK TABLES `MAP009` WRITE;
/*!40000 ALTER TABLE `MAP009` DISABLE KEYS */;
INSERT INTO `MAP009` VALUES ('','',0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1322,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP009` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP009_E`
--

DROP TABLE IF EXISTS `MAP009_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP009_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP009_E`
--

LOCK TABLES `MAP009_E` WRITE;
/*!40000 ALTER TABLE `MAP009_E` DISABLE KEYS */;
INSERT INTO `MAP009_E` VALUES ('MAP009',1329387507,33,'I','user','Set status=0 for id=, pwd=',NULL,NULL,NULL,NULL,NULL,'',NULL,1900,1,16,21,18),('MAP009',1329705099,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,13,31),('MAP009',1329705112,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,20,13,31),('MAP009',1330595903,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,1,20,58),('MAP009',1330596231,33,'I','user','Set status=0 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,1,21,3);
/*!40000 ALTER TABLE `MAP009_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP010`
--

DROP TABLE IF EXISTS `MAP010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP010` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  `APPROVED` int(11) DEFAULT '0',
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP010`
--

LOCK TABLES `MAP010` WRITE;
/*!40000 ALTER TABLE `MAP010` DISABLE KEYS */;
INSERT INTO `MAP010` VALUES ('AUTBYKCN','732048',4,'Tim Brough',1329079695,1329079695,1323,0,'artwork@airconway.com',137032112,0,0),('MCERUZSF','731878',0,'Emily Hsuing',1320083972,1320083972,NULL,0,'emily@badgeville.com',137111611,1,0),('DYKPACAS','731878',0,'Manjeera Patnaikuni',1320083972,1320083972,0,0,'manjeera@badgeville.com',137111611,1,0),('EXACRYDB','731878',4,'Paul Reeves',1320083972,1320083972,1307,0,'paul@badgeville.com',137111611,1,1),('MNKCTZUX','731878',4,'Kris Duggan',1320083972,1320083972,1306,0,'kris@badgeville.com',137111611,1,1),('DHAMUEMT','731878',4,'Raymond Lim',1320083972,1320083972,1305,0,'raymond@badgeville.com',137111611,1,1),('XFGCTHFG','731878',4,'Havy Nguyen',1320083972,1320083972,1001331,0,'havy@badgeville.com',137111611,1,1),('FZNUKXUX','731878',4,'Wedge Martin',1317793124,1317793124,1304,0,'wedge@badgeville.com',137111611,1,1),('YCGECXTX','731878',4,'Steve Sims',1317793124,1317793124,1303,0,'Steve@badgeville.com',137111611,1,1),('BXAZGRHG','731878',4,'Eric Montoya',1317793124,1317793124,1300,0,'eric@badgeville.com',137111611,1,1),('CDHFYAGX','731878',4,'Matt Hart',1317793124,1317793124,1301,0,'Matt@badgeville.com',137111611,1,1),('HZKHPRKC','731878',3,'Adena Demonte',1317793124,1317793124,1001333,0,'adena@badgeville.com',137111611,1,0),('UMYRNPKZ','732048',4,'Jud Dively',1329079696,1329079696,1324,0,'jdively@airconway.com',137032112,0,0),('TMUSZCTC','732048',4,'Beth Poletti',1329079696,1329079696,1325,0,'customerservice@airconway.com',137032112,0,0),('REXKYGTB','731878',4,'Mikkel Wong',1334140908,1334140908,1001332,0,'mikkelking@hotmail.com',137111611,1,1);
/*!40000 ALTER TABLE `MAP010` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP010A`
--

DROP TABLE IF EXISTS `MAP010A`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP010A` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP010A`
--

LOCK TABLES `MAP010A` WRITE;
/*!40000 ALTER TABLE `MAP010A` DISABLE KEYS */;
INSERT INTO `MAP010A` VALUES ('XBGEPMDN','732084',0,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1308,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1326,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP010A` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP010A_E`
--

DROP TABLE IF EXISTS `MAP010A_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP010A_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP010A_E`
--

LOCK TABLES `MAP010A_E` WRITE;
/*!40000 ALTER TABLE `MAP010A_E` DISABLE KEYS */;
INSERT INTO `MAP010A_E` VALUES ('MAP010A',1327277693,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,23,11,14),('MAP010A',1327317760,33,'I','user','Set status=3 for id=717588, pwd=ZHRYBRHT',NULL,NULL,NULL,NULL,NULL,'ZHRYBRHT',NULL,1900,1,23,22,22),('MAP010A',1333504287,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,11,51),('MAP010A',1333505523,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,12,12),('MAP010A',1334132196,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,11,18,16),('MAP010A',1334136588,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,11,19,29),('MAP010A',1334141048,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,11,20,44),('MAP010A',1334264207,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,13,6,56);
/*!40000 ALTER TABLE `MAP010A_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP010_E`
--

DROP TABLE IF EXISTS `MAP010_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP010_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP010_E`
--

LOCK TABLES `MAP010_E` WRITE;
/*!40000 ALTER TABLE `MAP010_E` DISABLE KEYS */;
INSERT INTO `MAP010_E` VALUES ('MAP010',1149120242,20,'I','system','sendmail:D9874B668C6 Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','andrewcreer@fastmail.fm',2006,6,1,10,4),('MAP010',1149120246,20,'I','system','sendmail:0A0B7F2119 Sending template \'peer\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','Bemy Peer1 <andrewcreer@fastmail.fm>',2006,6,1,10,4),('MAP010',1149207153,20,'I','system','sendmail:437D43C2E9E Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','andrewcreer@fastmail.fm',2006,6,2,10,12),('MAP010',1149827016,20,'I','system','sendmail:C8F22F1012 Sending template \'peer_reminder1\' email about \'Reminder: MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','Bemy Peer1 <andrewcreer@fastmail.fm>',2006,6,9,14,23),('MAP010',1149827019,20,'I','system','sendmail:3DF497625B0 Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','andrewcreer@fastmail.fm',2006,6,9,14,23),('MAP010',1149827020,20,'I','system','sendmail:4ECB43D00A9 Sending template \'peer_reminder1\' email about \'Reminder: MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Bemy Peer1 <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','Bemy Peer1 <andrewcreer@fastmail.fm>',2006,6,9,14,23),('MAP010',1149827021,20,'I','system','sendmail:5BE7911D4EA Sending template \'peer_escalate\' email about \'Peer Invitation Escalation\' to andrewcreer@fastmail.fm : OK',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH','andrewcreer@fastmail.fm',2006,6,9,14,23),('MAP010',1149830622,216,'I','escheme','MSG=24 TRACK=15 SCHEME=5 password=FBEUPSDH fullname=Bemy Peer1 uid=10001','Mozilla/5.0 ',NULL,NULL,NULL,'192.168.0.21','FBEUPSDH','andrewcreer@fastmail.fm',2006,6,9,15,23),('MAP010',1327277675,33,'I','user','Set status=3 for id=10001, pwd=FBEUPSDH',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH',NULL,1900,1,23,11,14),('MAP010',1327277828,33,'I','user','Set status=3 for id=10001, pwd=AEYGAMCP',NULL,NULL,NULL,NULL,NULL,'AEYGAMCP',NULL,1900,1,23,11,17),('MAP010',1327278152,36,'I','user','Set status=4 for id=10001, pwd=FBEUPSDH',NULL,NULL,NULL,NULL,NULL,'FBEUPSDH',NULL,1900,1,23,11,22),('MAP010',1327278304,36,'I','user','Set status=4 for id=10001, pwd=AEYGAMCP',NULL,NULL,NULL,NULL,NULL,'AEYGAMCP',NULL,1900,1,23,11,25),('MAP010',1333513062,33,'I','user','Set status=3 for id=731878, pwd=DYKPACAS',NULL,NULL,NULL,NULL,NULL,'DYKPACAS',NULL,1900,1,4,14,17),('MAP010',1333513112,36,'I','user','Set status=4 for id=731878, pwd=FZNUKXUX',NULL,NULL,NULL,NULL,NULL,'FZNUKXUX',NULL,1900,1,4,14,18),('MAP010',1333513614,36,'I','user','Set status=4 for id=731878, pwd=FZNUKXUX',NULL,NULL,NULL,NULL,NULL,'FZNUKXUX',NULL,1900,1,4,14,26),('MAP010',1334121261,36,'I','user','Set status=4 for id=731878, pwd=XFGCTHFG',NULL,NULL,NULL,NULL,NULL,'XFGCTHFG',NULL,1900,1,11,15,14),('MAP010',1334121424,36,'I','user','Set status=4 for id=731878, pwd=XFGCTHFG',NULL,NULL,NULL,NULL,NULL,'XFGCTHFG',NULL,1900,1,11,15,17),('MAP010',1334121467,36,'I','user','Set status=4 for id=731878, pwd=XFGCTHFG',NULL,NULL,NULL,NULL,NULL,'XFGCTHFG',NULL,1900,1,11,15,17),('MAP010',1334140972,33,'I','user','Set status=3 for id=731878, pwd=REXKYGTB',NULL,NULL,NULL,NULL,NULL,'REXKYGTB',NULL,1900,1,11,20,42),('MAP010',1334141036,36,'I','user','Set status=4 for id=731878, pwd=REXKYGTB',NULL,NULL,NULL,NULL,NULL,'REXKYGTB',NULL,1900,1,11,20,43),('MAP010',1334191234,33,'I','user','Set status=0 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,40),('MAP010',1334191266,33,'I','user','Set status=0 for id=731878, pwd=DYKPACAS',NULL,NULL,NULL,NULL,NULL,'DYKPACAS',NULL,1900,1,12,10,41),('MAP010',1334191282,33,'I','user','Set status=3 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,41),('MAP010',1334191302,33,'I','user','Set status=3 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,41),('MAP010',1334191408,33,'I','user','Set status=3 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,43),('MAP010',1334191481,33,'I','user','Set status=3 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,44),('MAP010',1334191622,33,'I','user','Set status=3 for id=731878, pwd=HZKHPRKC',NULL,NULL,NULL,NULL,NULL,'HZKHPRKC',NULL,1900,1,12,10,47);
/*!40000 ALTER TABLE `MAP010_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP011`
--

DROP TABLE IF EXISTS `MAP011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP011` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP011`
--

LOCK TABLES `MAP011` WRITE;
/*!40000 ALTER TABLE `MAP011` DISABLE KEYS */;
INSERT INTO `MAP011` VALUES ('HFNSGABA','732084',0,'Sonny Newman',1331118313,1331118313,NULL,0,'snewman@eetechinc.com',0,0),('DBMYNMSZ','731878',4,'Kevin Akeroyd',1317772210,1317772210,1309,0,'Kevin@badgeville.com',0,1);
/*!40000 ALTER TABLE `MAP011` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP011_E`
--

DROP TABLE IF EXISTS `MAP011_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP011_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL,
  `TP` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP011_E`
--

LOCK TABLES `MAP011_E` WRITE;
/*!40000 ALTER TABLE `MAP011_E` DISABLE KEYS */;
INSERT INTO `MAP011_E` VALUES ('MAP011',1148965201,20,'I','system','sendmail:816DDF072A Sending template \'boss\' email about \'MAP - May 29, 2006 deadline - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG','Boss Bossman <andrewcreer@fastmail.fm>',2006,5,30,15,0,0),('MAP011',1148965215,20,'I','system','sendmail:37DB0761F86 Sending template \'boss_reminder1\' email about \'Reminder: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG','Boss Bossman <andrewcreer@fastmail.fm>',2006,5,30,15,0,0),('MAP011',1148965218,20,'I','system','sendmail:64FF0B60A98 Sending template \'boss_reminder2\' email about \'Reminder 2: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG','Boss Bossman <andrewcreer@fastmail.fm>',2006,5,30,15,0,0),('MAP011',1148965382,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Mozilla/5.0 ',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,3,0),('MAP011',1148965413,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,3,0),('MAP011',1148965418,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,3,0),('MAP011',1148965443,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,4,0),('MAP011',1148965445,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,4,0),('MAP011',1148965467,216,'I','escheme','MSG=10 TRACK=6 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,5,30,15,4,0),('MAP011',1149120240,20,'I','system','sendmail:1B52F3D3217 Sending template \'boss_reminder3\' email about \'Reminder 3: MAP - May 29, 2006 - MAP Workshop Materials\' to Boss Bossman <andrewcreer@fastmail.fm> : OK',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG','Boss Bossman <andrewcreer@fastmail.fm>',2006,6,1,10,4,43),('MAP011',1149569912,216,'I','escheme','MSG=13 TRACK=9 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Mozilla/5.0 ',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,6,6,14,58,NULL),('MAP011',1149569950,216,'I','escheme','MSG=13 TRACK=9 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,6,6,14,59,NULL),('MAP011',1149569953,216,'I','escheme','MSG=13 TRACK=9 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,6,6,14,59,NULL),('MAP011',1149569989,216,'I','escheme','MSG=13 TRACK=9 SCHEME=3 password=YNYCPYUG fullname=Boss Bossman uid=10001','Opera/8.5 (X',NULL,NULL,NULL,'192.168.0.21','YNYCPYUG','andrewcreer@fastmail.fm',2006,6,6,14,59,NULL),('MAP011',1149827810,20,'I','system','sendmail:6B5247624EE Sending template \'boss\' email about \'MAP - May 21, 2003 deadline - MAP Workshop Materials\' to Mike King <mikkel@market-research.com> : OK',NULL,NULL,NULL,NULL,NULL,'MBMXURDZ','Mike King <mikkel@market-research.com>',2006,6,9,14,36,NULL),('MAP011',1329388680,33,'I','user','Set status=3 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,38,NULL),('MAP011',1329388756,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,39,NULL),('MAP011',1329388759,33,'I','user','Set status=3 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,39,NULL),('MAP011',1330596512,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,1,21,8,NULL),('MAP011',1333513785,36,'I','user','Set status=4 for id=731878, pwd=DBMYNMSZ',NULL,NULL,NULL,NULL,NULL,'DBMYNMSZ',NULL,1900,1,4,14,29,NULL);
/*!40000 ALTER TABLE `MAP011_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP012`
--

DROP TABLE IF EXISTS `MAP012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP012` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP012`
--

LOCK TABLES `MAP012` WRITE;
/*!40000 ALTER TABLE `MAP012` DISABLE KEYS */;
INSERT INTO `MAP012` VALUES ('HFNSGABA','732084',0,'Sonny Newman',1331118313,1331118313,NULL,0,'snewman@eetechinc.com',0,NULL),('DBMYNMSZ','731878',4,'Kevin Akeroyd',1317772210,1317772210,1310,0,'Kevin@badgeville.com',0,NULL);
/*!40000 ALTER TABLE `MAP012` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP012_E`
--

DROP TABLE IF EXISTS `MAP012_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP012_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP012_E`
--

LOCK TABLES `MAP012_E` WRITE;
/*!40000 ALTER TABLE `MAP012_E` DISABLE KEYS */;
INSERT INTO `MAP012_E` VALUES ('MAP012',1329388971,33,'I','user','Set status=3 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,42),('MAP012',1329389200,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,46),('MAP012',1329389282,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,48),('MAP012',1329389295,33,'I','user','Set status=3 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,48),('MAP012',1329389301,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,48),('MAP012',1329389305,33,'I','user','Set status=3 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,16,21,48),('MAP012',1330596525,33,'I','user','Set status=0 for id=10001, pwd=YNYCPYUG',NULL,NULL,NULL,NULL,NULL,'YNYCPYUG',NULL,1900,1,1,21,8),('MAP012',1333513749,36,'I','user','Set status=4 for id=731878, pwd=DBMYNMSZ',NULL,NULL,NULL,NULL,NULL,'DBMYNMSZ',NULL,1900,1,4,14,29);
/*!40000 ALTER TABLE `MAP012_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP018`
--

DROP TABLE IF EXISTS `MAP018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP018` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `STOP_FLAG` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP018`
--

LOCK TABLES `MAP018` WRITE;
/*!40000 ALTER TABLE `MAP018` DISABLE KEYS */;
INSERT INTO `MAP018` VALUES ('XBGEPMDN','732084',3,'Barbara Bristol',1331118313,1331118313,NULL,0,'barbara@eetechinc.com',0,NULL),('BGBXPGFE','731878',4,'Scott Schnaars',1317772210,1317772210,1311,0,'scott@badgeville.com',0,NULL),('FUZHDNRY','732048',4,'Brian Conway',1328124027,1328124027,1327,0,'bconway@airconway.com',0,NULL);
/*!40000 ALTER TABLE `MAP018` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP018_E`
--

DROP TABLE IF EXISTS `MAP018_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP018_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP018_E`
--

LOCK TABLES `MAP018_E` WRITE;
/*!40000 ALTER TABLE `MAP018_E` DISABLE KEYS */;
INSERT INTO `MAP018_E` VALUES ('MAP018',1329431387,33,'I','user','Set status=3 for id=10001, pwd=YEGSTCDK',NULL,NULL,NULL,NULL,NULL,'YEGSTCDK',NULL,1900,1,17,9,29),('MAP018',1331246818,33,'I','user','Set status=3 for id=732084, pwd=XBGEPMDN',NULL,NULL,NULL,NULL,NULL,'XBGEPMDN',NULL,1900,1,9,9,46),('MAP018',1333509966,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,13,26);
/*!40000 ALTER TABLE `MAP018_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP026`
--

DROP TABLE IF EXISTS `MAP026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP026` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `STAT` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP026`
--

LOCK TABLES `MAP026` WRITE;
/*!40000 ALTER TABLE `MAP026` DISABLE KEYS */;
INSERT INTO `MAP026` VALUES ('BGBXPGFE','731878',4,'Scott Schnaars',1321873580,1321873580,1312,0,'scott@badgeville.com',0);
/*!40000 ALTER TABLE `MAP026` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP026_E`
--

DROP TABLE IF EXISTS `MAP026_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP026_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP026_E`
--

LOCK TABLES `MAP026_E` WRITE;
/*!40000 ALTER TABLE `MAP026_E` DISABLE KEYS */;
INSERT INTO `MAP026_E` VALUES ('MAP026',1333505647,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,12,14),('MAP026',1333513051,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,14,17),('MAP026',1333513880,36,'I','user','Set status=4 for id=731878, pwd=BGBXPGFE',NULL,NULL,NULL,NULL,NULL,'BGBXPGFE',NULL,1900,1,4,14,31);
/*!40000 ALTER TABLE `MAP026_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP101`
--

DROP TABLE IF EXISTS `MAP101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP101` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP101`
--

LOCK TABLES `MAP101` WRITE;
/*!40000 ALTER TABLE `MAP101` DISABLE KEYS */;
INSERT INTO `MAP101` VALUES ('YNYCPYUG','10001',0,'Boss Bossman',1147220187,1147220187,NULL,0,'andrewcreer@fastmail.fm',0),('YEGSTCDK','10001',0,'Andrew Creer',1147220186,1147220186,NULL,0,'ac@market-research.com',0),('FBEUPSDH','10001',0,'Bemy Peer',1148967783,1148967783,NULL,0,'andrewcreer@fastmail.fm',1),('ZGDUBGMT','717572',0,'Randy Gray',1149826693,1149826693,NULL,0,'ac@market-research.com',0),('ZHRYBRHT','717588',0,'Craig Snyder',1149826693,1149826693,NULL,0,'mikkel@market-research.com',0),('MBMXURDZ','717588',0,'Mike King',1149827768,1149827768,NULL,0,'mikkel@market-research.com',1),('AEYGAMCP','10001',0,'Mor Kel',1327277734,1327277734,NULL,0,'mikkelking@hotmail.com',1),('REXKYGTB','731878',0,'Mikkel Wong',1334140908,1334140908,NULL,0,'mikkelking@hotmail.com',137111611),('ARTBDSTG','731878',0,'Fok Mee Wong',1334186785,1334186785,NULL,0,'mikkelking@hotmail.com',137111611);
/*!40000 ALTER TABLE `MAP101` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP101_E`
--

DROP TABLE IF EXISTS `MAP101_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP101_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP101_E`
--

LOCK TABLES `MAP101_E` WRITE;
/*!40000 ALTER TABLE `MAP101_E` DISABLE KEYS */;
/*!40000 ALTER TABLE `MAP101_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAP_CASES`
--

DROP TABLE IF EXISTS `MAP_CASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MAP_CASES` (
  `CASENAME` varchar(12) NOT NULL,
  `SID` varchar(8) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `FULLNAME` varchar(40) DEFAULT NULL,
  `ROLENAME` varchar(20) NOT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `SORT_ORDER` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAP_CASES`
--

LOCK TABLES `MAP_CASES` WRITE;
/*!40000 ALTER TABLE `MAP_CASES` DISABLE KEYS */;
INSERT INTO `MAP_CASES` VALUES ('pwikit','MAP010','731810','EBTRFTKC','Suzanne Beeks','Peer',143092111,0),('pwikit','MAP010','731810','BSKDUYFR','Andy Allison','Peer',143092111,0),('pwikit','MAP010','731810','TSBDMGSC','Dee Dee Land','Peer',143092111,0),('pwikit','MAP010','731810','RSBTPFYM','Tannen Ellis','Peer',143092111,0),('pwikit','MAP010','731810','UXECEXAE','Gary Christensen','Peer',143092111,0),('pwikit','MAP009','731810','UERYHSMN','Brent Andersen','Self',143092111,10),('pwikit','MAP008','731810','UERYHSMN','Brent Andersen','Self',143092111,9),('pwikit','MAP018','731810','UERYHSMN','Brent Andersen','Self',143092111,11),('pwikit','MAP010A','731810','UERYHSMN','Brent Andersen','Self',143092111,1),('pwikit','MAP007','731810','UERYHSMN','Brent Andersen','Self',143092111,8),('pwikit','MAP006','731810','UERYHSMN','Brent Andersen','Self',143092111,7),('pwikit','MAP005','731810','UERYHSMN','Brent Andersen','Self',143092111,2),('pwikit','MAP004','731810','UERYHSMN','Brent Andersen','Self',143092111,6),('pwikit','MAP003','731810','UERYHSMN','Brent Andersen','Self',143092111,5),('pwikit','MAP001','731810','UERYHSMN','Brent Andersen','Self',143092111,3),('pwikit','MAP002','731810','UERYHSMN','Brent Andersen','Self',143092111,4),('pwikit','MAP003','731878','BGBXPGFE','Scott Schnaars','Self',137111611,5),('pwikit','MAP002','731878','BGBXPGFE','Scott Schnaars','Self',137111611,4),('pwikit','MAP001','731878','BGBXPGFE','Scott Schnaars','Self',137111611,3),('pwikit','MAP012','732084','HFNSGABA','Sonny Newman','Boss',137032112,302),('pwikit','MAP010A','732084','XBGEPMDN','Barbara Bristol','Self',137032112,1),('pwikit','MAP018','732084','XBGEPMDN','Barbara Bristol','Self',137032112,11),('pwikit','MAP011','732084','HFNSGABA','Sonny Newman','Boss',137032112,301),('pwikit','MAP007','732084','XBGEPMDN','Barbara Bristol','Self',137032112,8),('pwikit','MAP006','732084','XBGEPMDN','Barbara Bristol','Self',137032112,7),('pwikit','MAP004','732084','XBGEPMDN','Barbara Bristol','Self',137032112,6),('pwikit','MAP005','732084','XBGEPMDN','Barbara Bristol','Self',137032112,2),('pwikit','MAP001','732084','XBGEPMDN','Barbara Bristol','Self',137032112,3),('pwikit','MAP002','732084','XBGEPMDN','Barbara Bristol','Self',137032112,4),('pwikit','MAP003','732084','XBGEPMDN','Barbara Bristol','Self',137032112,5),('pwikit','MAP026','731810','UERYHSMN','Brent Andersen','Self',143092111,12),('pwikit','MAP010','731810','APCATCEH','Chris Barela','Peer',143092111,0),('pwikit','MAP010','731810','MTYZYFXS','Angie Hyde','Peer',143092111,0),('pwikit','MAP010','731810','KEPMPMAB','Matt Jacobsen','Peer',143092111,0),('pwikit','MAP010','731810','AHUYSNBX','Melissa Bowers','Peer',143092111,0),('pwikit','MAP010','731810','GCNHPSRN','Ronnie Daniel','Peer',143092111,0),('pwikit','MAP010','731810','NSHXRZEK','Jana Rae Shaw','Peer',143092111,0),('pwikit','MAP010','731878','REXKYGTB','Mikkel Wong','Peer',137111611,0),('pwikit','MAP010','732048','TMUSZCTC','Beth Poletti','Peer',137032112,0),('pwikit','MAP010','732048','UMYRNPKZ','Jud Dively','Peer',137032112,0),('pwikit','MAP010','732048','AUTBYKCN','Tim Brough','Peer',137032112,0),('pwikit','MAP009','732048','FUZHDNRY','Brian Conway','Self',137032112,10),('pwikit','MAP008','732048','FUZHDNRY','Brian Conway','Self',137032112,9),('pwikit','MAP018','732048','FUZHDNRY','Brian Conway','Self',137032112,11),('pwikit','MAP010A','732048','FUZHDNRY','Brian Conway','Self',137032112,1),('pwikit','MAP007','732048','FUZHDNRY','Brian Conway','Self',137032112,8),('pwikit','MAP006','732048','FUZHDNRY','Brian Conway','Self',137032112,7),('pwikit','MAP005','732048','FUZHDNRY','Brian Conway','Self',137032112,2),('pwikit','MAP004','732048','FUZHDNRY','Brian Conway','Self',137032112,6),('pwikit','MAP003','732048','FUZHDNRY','Brian Conway','Self',137032112,5),('pwikit','MAP002','732048','FUZHDNRY','Brian Conway','Self',137032112,4),('pwikit','MAP001','732048','FUZHDNRY','Brian Conway','Self',137032112,3),('pwikit','MAP010','731878','MCERUZSF','Emily Hsuing','Peer',137111611,0),('pwikit','MAP026','731878','BGBXPGFE','Scott Schnaars','Self',137111611,12),('pwikit','MAP010','731878','DYKPACAS','Manjeera Patnaikuni','Peer',137111611,0),('pwikit','MAP010','731878','EXACRYDB','Paul Reeves','Peer',137111611,0),('pwikit','MAP010','731878','MNKCTZUX','Kris Duggan','Peer',137111611,0),('pwikit','MAP010','731878','DHAMUEMT','Raymond Lim','Peer',137111611,0),('pwikit','MAP010','731878','XFGCTHFG','Havy Nguyen','Peer',137111611,0),('pwikit','MAP010','731878','FZNUKXUX','Wedge Martin','Peer',137111611,0),('pwikit','MAP010','731878','YCGECXTX','Steve Sims','Peer',137111611,0),('pwikit','MAP010','731878','HZKHPRKC','Adena Demonte','Peer',137111611,0),('pwikit','MAP010','731878','CDHFYAGX','Matt Hart','Peer',137111611,0),('pwikit','MAP010','731878','BXAZGRHG','Eric Montoya','Peer',137111611,0),('pwikit','MAP012','731878','DBMYNMSZ','Kevin Akeroyd','Boss',137111611,302),('pwikit','MAP011','731878','DBMYNMSZ','Kevin Akeroyd','Boss',137111611,301),('pwikit','MAP018','731878','BGBXPGFE','Scott Schnaars','Self',137111611,11),('pwikit','MAP010A','731878','BGBXPGFE','Scott Schnaars','Self',137111611,1),('pwikit','MAP007','731878','BGBXPGFE','Scott Schnaars','Self',137111611,8),('pwikit','MAP006','731878','BGBXPGFE','Scott Schnaars','Self',137111611,7),('pwikit','MAP004','731878','BGBXPGFE','Scott Schnaars','Self',137111611,6),('pwikit','MAP005','731878','BGBXPGFE','Scott Schnaars','Self',137111611,2);
/*!40000 ALTER TABLE `MAP_CASES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PARTICIPANT`
--

DROP TABLE IF EXISTS `PARTICIPANT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PARTICIPANT` (
  `PWD` varchar(12) NOT NULL,
  `UID` varchar(50) DEFAULT NULL,
  `STAT` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `TS` int(11) DEFAULT NULL,
  `EXPIRES` int(11) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `REMINDERS` int(11) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  PRIMARY KEY (`PWD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PARTICIPANT`
--

LOCK TABLES `PARTICIPANT` WRITE;
/*!40000 ALTER TABLE `PARTICIPANT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PARTICIPANT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PARTICIPANT_E`
--

DROP TABLE IF EXISTS `PARTICIPANT_E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PARTICIPANT_E` (
  `SID` varchar(10) NOT NULL,
  `TS` int(11) NOT NULL,
  `EVENT_CODE` int(11) NOT NULL,
  `SEVERITY` char(1) NOT NULL,
  `WHO` varchar(10) NOT NULL,
  `CAPTION` varchar(200) DEFAULT NULL,
  `BROWSER` varchar(12) DEFAULT NULL,
  `BROWSER_VER` varchar(8) DEFAULT NULL,
  `OS` varchar(12) DEFAULT NULL,
  `OS_VER` varchar(8) DEFAULT NULL,
  `IPADDR` varchar(15) DEFAULT NULL,
  `PWD` varchar(12) DEFAULT NULL,
  `EMAIL` varchar(80) DEFAULT NULL,
  `YR` int(11) DEFAULT NULL,
  `MON` int(11) DEFAULT NULL,
  `MDAY` int(11) DEFAULT NULL,
  `HR` int(11) DEFAULT NULL,
  `MINS` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PARTICIPANT_E`
--

LOCK TABLES `PARTICIPANT_E` WRITE;
/*!40000 ALTER TABLE `PARTICIPANT_E` DISABLE KEYS */;
/*!40000 ALTER TABLE `PARTICIPANT_E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_ADMIN`
--

DROP TABLE IF EXISTS `PWI_ADMIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_ADMIN` (
  `ADMIN_KV` int(11) NOT NULL,
  `ADMIN_ID` varchar(12) NOT NULL,
  `ADMIN_NAME` varchar(50) NOT NULL,
  `ADMIN_EMAIL` varchar(100) NOT NULL,
  `ADMIN_PHONE` varchar(30) DEFAULT NULL,
  `ADMIN_FAX` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ADMIN_KV`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_ADMIN`
--

LOCK TABLES `PWI_ADMIN` WRITE;
/*!40000 ALTER TABLE `PWI_ADMIN` DISABLE KEYS */;
INSERT INTO `PWI_ADMIN` VALUES (1,'1','Admin Creer','ac@market-research.com','1800-ph-AdminCreer','1800-fx-AdminCreer'),(2,'231','Timothy King','trking@mapconsulting.com',NULL,NULL),(3,'493','Melissa Doty','madoty@mapconsulting.com',NULL,NULL),(4,'440','Wendi Foxhoven','wwfoxhoven@mapconsulting.com',NULL,NULL),(5,'662','Cecelia Forrest','cmforrest@mapconsulting.com',NULL,NULL),(6,'624','Catherine Webb','ctwebb@mapconsulting.com',NULL,NULL),(7,'62','Tammy Tougas','tmtougas@mapconsulting.com',NULL,NULL),(8,'693','Bethany Cruz','bdcruz@mapconsulting.com',NULL,NULL),(9,'1048','Kathleen Cooney','kcooney@mapconsulting.com',NULL,NULL),(10,'767','Vanessa Rivera','vrivera@mapconsulting.com',NULL,NULL),(11,'1049','Michelle Belina','mlbelina@mapconsulting.com',NULL,NULL),(12,'791','Holly King','hdking@mapconsulting.com',NULL,NULL);
/*!40000 ALTER TABLE `PWI_ADMIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_BATCH`
--

DROP TABLE IF EXISTS `PWI_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_BATCH` (
  `BAT_KV` int(11) NOT NULL,
  `BAT_NO` int(11) NOT NULL,
  `BAT_NAME` varchar(50) NOT NULL,
  `BAT_STATUS` int(11) NOT NULL,
  PRIMARY KEY (`BAT_KV`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_BATCH`
--

LOCK TABLES `PWI_BATCH` WRITE;
/*!40000 ALTER TABLE `PWI_BATCH` DISABLE KEYS */;
INSERT INTO `PWI_BATCH` VALUES (1,1,'Testing Batch',1);
/*!40000 ALTER TABLE `PWI_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_EXEC`
--

DROP TABLE IF EXISTS `PWI_EXEC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_EXEC` (
  `EXEC_KV` int(11) NOT NULL,
  `EXEC_NAME` varchar(50) NOT NULL,
  `EXEC_EMAIL` varchar(100) NOT NULL,
  `EXEC_PHONE` varchar(30) DEFAULT NULL,
  `EXEC_FAX` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`EXEC_KV`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_EXEC`
--

LOCK TABLES `PWI_EXEC` WRITE;
/*!40000 ALTER TABLE `PWI_EXEC` DISABLE KEYS */;
INSERT INTO `PWI_EXEC` VALUES (1,'Exec Creer','andrewcreer@fastmail.fm','1800-ph-ExecCreer','1800-fx-ExecCreer'),(2,'Mike King','mikkel@market-research.com','911','911');
/*!40000 ALTER TABLE `PWI_EXEC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_LOCATION`
--

DROP TABLE IF EXISTS `PWI_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_LOCATION` (
  `LOC_KV` int(11) NOT NULL,
  `LOC_ID` int(11) NOT NULL,
  `LOC_CODE` varchar(12) NOT NULL,
  `LOC_NAME` varchar(50) NOT NULL,
  `LOC_DISPLAY` varchar(50) DEFAULT NULL,
  `LOC_ACTIVE` int(11) DEFAULT '1',
  `LOC_FAX` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`LOC_KV`),
  UNIQUE KEY `LOC_CODE` (`LOC_CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_LOCATION`
--

LOCK TABLES `PWI_LOCATION` WRITE;
/*!40000 ALTER TABLE `PWI_LOCATION` DISABLE KEYS */;
INSERT INTO `PWI_LOCATION` VALUES (1,1,'','Seddon','The Seddon house of Management',NULL,'1800-fx-location'),(2,2,'AZ01','Sheraton San Marcos',NULL,0,''),(3,3,'AZ02','Embassy Suites Hotel-AZ',NULL,0,''),(4,4,'AZ03','Arizona Biltmore',NULL,0,''),(5,5,'AZ04','Sheraton Crescent Hotel',NULL,0,''),(6,7,'AZ06','Carefree Conference Rsrt',NULL,0,''),(7,8,'AZ07','Scottsdale Conference Rst',NULL,0,''),(8,9,'AZ08','Bank One Ballpark',NULL,0,''),(9,10,'HI01','Ala Moana Hotel',NULL,0,''),(10,11,'LV01','MAP',NULL,0,'(702) 736-7171'),(11,12,'LV02','Mt. Charleston Hotel',NULL,0,''),(12,13,'LV03','St. Tropez Suite Hotel',NULL,0,''),(13,14,'LV04','Casablanca Resort Hotel',NULL,0,''),(14,15,'LV05','Eureka Hotel & Casino',NULL,0,'(702) 346-4680'),(15,16,'M501','Test MAP II Site',NULL,0,''),(16,17,'MT01','Cavanaughs Colonial Hotel',NULL,0,''),(17,18,'MT03','Rainbow Ranch Lodge',NULL,0,'(702) 736-7171'),(18,19,'NC01','Westin Hotel @ SF Airport',NULL,0,''),(19,20,'NC03','Claremont Resort',NULL,0,''),(20,21,'NC04','Sheraton Suites',NULL,0,''),(21,22,'NC05','Embassy Suites',NULL,0,''),(22,23,'NC06','Sheraton Pleasanton',NULL,0,''),(23,24,'NC07','Embassy Suites Hotel',NULL,0,'(707) 253-9202'),(24,25,'NC08','Monterey Beach Hotel',NULL,0,''),(25,26,'NC09','Hotel Sofitel',NULL,0,''),(26,27,'NC10','Embassy Suites',NULL,0,''),(27,28,'NC11','Napa Valley Marriott',NULL,0,'(707) 258-1320'),(28,29,'NC12','Marriott\'s Tenaya Lodge',NULL,0,''),(29,30,'NC13','Sheraton',NULL,0,''),(30,31,'NC14','Westin Hotel',NULL,0,''),(31,32,'NC17','Embassy Suites',NULL,0,''),(32,33,'NC18','Red Lion Inn',NULL,0,''),(33,34,'NC21','Embassy Suites',NULL,0,''),(34,35,'NC22','Red Lion Hotel',NULL,0,''),(35,36,'NC23','Courtyard Marriott',NULL,0,''),(36,37,'NC24','Red Lion',NULL,0,''),(37,39,'NW01','MAP, Inc.',NULL,0,''),(38,40,'NW02','Westmark Hotel',NULL,0,''),(39,41,'NW03','WestCoast Bellevue Hotel',NULL,0,''),(40,42,'NW04','Red Lion Bellevue Inn',NULL,0,''),(41,43,'NW05','Columbia Gorge Hotel',NULL,0,''),(42,44,'NW06','Salish Lodge',NULL,0,''),(43,45,'NW07','Hyatt Regency Bellevue',NULL,0,'(425) 698-4281'),(44,46,'NW08','Park Plaza Hotel',NULL,0,''),(45,47,'NW09','Riverplace Hotel',NULL,0,''),(46,48,'NW10','Best Western Southcenter',NULL,0,''),(47,49,'NW11','Wyndham Garden Hotel',NULL,0,''),(48,50,'NW12','Mat-Su Resort',NULL,0,''),(49,51,'NW13','Clarion Hotel',NULL,0,''),(50,52,'NW14','Doubletree Suites',NULL,0,''),(51,53,'NW16','Inn At Semi-Ah-Moo',NULL,0,''),(52,54,'NW17','Woodmark Hotel',NULL,0,''),(53,55,'NW18','Marriott Suites',NULL,0,''),(54,56,'NW19','Coeur d\'Alene Resort',NULL,0,''),(55,57,'OO01','Bellevue Hilton Inn',NULL,0,''),(56,58,'OR01','Embassy Suites Downtown',NULL,0,''),(57,59,'OR02','Crown Plaza Hotel',NULL,0,''),(58,60,'R101','Radisson Hotel',NULL,0,''),(59,61,'R102','MAP, Inc.',NULL,0,''),(60,62,'R103','MAP',NULL,0,''),(61,63,'R201','MAP Office',NULL,0,''),(62,64,'R202','HQ San Francisco',NULL,0,''),(63,65,'R203','Westin Hotel @ SF Airport',NULL,0,''),(64,66,'R204','Autumn Moon Cafe',NULL,0,''),(65,67,'R301','Bellevue Conference Ctr.',NULL,0,''),(66,68,'R302','MAP Bellevue Office',NULL,0,''),(67,69,'R303','Park Plaza Hotel',NULL,0,''),(68,70,'R304','Cavanaughs Colonial Hotel',NULL,0,''),(69,71,'R305','Rainbow Ranch Lodge',NULL,0,''),(70,72,'R310','TBA',NULL,0,''),(71,73,'R311','TBA',NULL,0,''),(72,74,'R312','Cavanaugh\'s at the Park',NULL,0,''),(73,75,'R401','Balboa Bay Club',NULL,0,''),(74,76,'R402','MAP Newport Beach',NULL,0,''),(75,77,'R403','Location to be determined',NULL,0,''),(76,78,'R601','MAP TX Office',NULL,0,''),(77,79,'R701','MAP AZ Office',NULL,0,''),(78,80,'R702','Embassy Suites Hotel',NULL,0,''),(79,81,'R703','Arizona Country Club',NULL,0,''),(80,82,'R801','MAP San Diego',NULL,0,''),(81,83,'SC01','Gold Canyon Ranch',NULL,0,''),(82,84,'SC02','Balboa Bay Club',NULL,0,''),(83,85,'SC03','The Sutton Place Hotel',NULL,0,''),(84,86,'SC04','Embassy Suites Hotel',NULL,0,''),(85,87,'SC05','So. Cal. location TBD',NULL,0,''),(86,88,'SC06','Wyndham Garden Hotel',NULL,0,''),(87,89,'SC07','Country Side Inn & Suites',NULL,0,''),(88,90,'SC08','Warner Center Marriott',NULL,0,''),(89,91,'SC09','Park Hyatt Los Angeles',NULL,0,''),(90,92,'SC10','Hyatt Newporter Inn',NULL,0,''),(91,94,'SC12','Ritz Carlton',NULL,0,''),(92,95,'SC13','Portofino Inn',NULL,0,''),(93,96,'SC14','Doubletree Hotel',NULL,0,''),(94,97,'SC15','Pala Mesa Resort',NULL,0,''),(95,98,'SC16','Radisson Newport Beach',NULL,0,''),(96,99,'SC17','WestCoast Long Beach',NULL,0,''),(97,103,'SC99','San Diego Area',NULL,0,''),(98,104,'TX01','Arlington Marriot Hotel',NULL,0,''),(99,105,'TX02','Marriott Solana',NULL,0,''),(100,106,'TX03','The Harvey Hotel & Suites',NULL,0,''),(101,107,'TX04','Crowne Plaza Hotel-Resort',NULL,0,''),(102,108,'TX05','Double Tree Hotel Dallas',NULL,0,''),(103,109,'UT01','Cavanaugh\'s Olympus Hotel',NULL,0,''),(104,110,'UT02','Radisson Hotel Park City',NULL,0,''),(105,111,'UT03','Larry Miller Center, SLCC',NULL,0,''),(106,112,'WE01','Washington Employers Assoc.',NULL,0,'(206) 328-0131'),(107,113,'Z101','MAP-Sherman Oaks',NULL,0,''),(108,114,'Z201','Autumn Moon Cafe',NULL,0,''),(109,115,'Z801','MAP-Nevada',NULL,0,''),(110,117,'TX06','Hilton Dallas/Park Cities',NULL,0,'(214) 691-3157'),(111,118,'LV06','Alexis Park Resort',NULL,0,'(702) 796-0766'),(112,119,'MTR01','Envirocon, Inc. (MAP II)',NULL,0,'(702) 736-7171'),(113,120,'AZ09','Doubletree Guest Suites - Phx',NULL,0,'(602) 231-0561'),(114,122,'LV10','JW Marriott Resort/Spa',NULL,0,'(702) 796-8376'),(115,123,'NC02','MAP Oakland',NULL,0,''),(116,124,'MTR02','Missoula Family YMCA',NULL,0,'(406) 721-9226'),(117,125,'LV11','Boulder Station Hotel & Casino',NULL,0,'(702) 432-7506'),(118,126,'LV12','AGC of Georgia',NULL,0,'(678) 298-4101'),(119,127,'UT04','The Homestead',NULL,0,'(435) 654-5087'),(120,129,'WE02','Best Wstrn. Plaza on the Green',NULL,0,'(253) 850-7667'),(121,130,'LV13','Las Vegas MAPII Location',NULL,0,''),(122,131,'Z102','Empire Companies',NULL,0,'(909) 980-7305'),(123,132,'UT05','Hidden Valley Country Club',NULL,0,''),(124,133,'UT06','Best Western - Cotton Tree Inn',NULL,0,''),(125,134,'UT07','Utah-location to be determined',NULL,0,''),(126,135,'SC00','S.O. - In House MAPII Programs',NULL,0,''),(127,100,'SC18','Marriott Hotel & Tennis Club',NULL,0,''),(128,101,'SC19','Marriott Suites, Newport',NULL,0,''),(129,121,'SC21','Irvine Marriott',NULL,0,'(949) 261-7059'),(130,102,'SC20','Costa Mesa Marriott Suites',NULL,0,''),(131,136,'WE03','Marriott-Lake Union Courtyard',NULL,0,'(206) 260-8928'),(132,128,'NC15','Hilton Garden Inn',NULL,0,'(707) 252-0244'),(133,6,'AZ05','Gold Canyon Golf Resort',NULL,0,'');
/*!40000 ALTER TABLE `PWI_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_STATUS`
--

DROP TABLE IF EXISTS `PWI_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_STATUS` (
  `UID` varchar(50) NOT NULL,
  `PWD` varchar(15) DEFAULT NULL,
  `CNT` int(11) DEFAULT NULL,
  `ISREADY` int(11) DEFAULT NULL,
  `Q1` int(11) DEFAULT NULL,
  `Q2` int(11) DEFAULT NULL,
  `Q3` int(11) DEFAULT NULL,
  `Q4` int(11) DEFAULT NULL,
  `Q5` int(11) DEFAULT NULL,
  `Q6` int(11) DEFAULT NULL,
  `Q7` int(11) DEFAULT NULL,
  `Q8` int(11) DEFAULT NULL,
  `Q9` int(11) DEFAULT NULL,
  `Q10A` int(11) DEFAULT NULL,
  `Q10` int(11) DEFAULT NULL,
  `Q11` int(11) DEFAULT NULL,
  `Q12` int(11) DEFAULT NULL,
  `FULLNAME` varchar(60) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `EXECNAME` varchar(60) DEFAULT NULL,
  `LOCID` varchar(12) DEFAULT NULL,
  `LOCNAME` varchar(60) DEFAULT NULL,
  `WSID` varchar(25) DEFAULT NULL,
  `WSDATE` varchar(30) DEFAULT NULL,
  `WSDATE_D` date DEFAULT NULL,
  `DUEDATE` varchar(30) DEFAULT NULL,
  `DUEDATE_D` date DEFAULT NULL,
  `NBOSS` int(11) DEFAULT NULL,
  `NPEER` int(11) DEFAULT NULL,
  `CREDIT_CARD_HOLDER` varchar(40) DEFAULT NULL,
  `CCT_ID` varchar(12) DEFAULT NULL,
  `CREDIT_CARD_NO` varchar(20) DEFAULT NULL,
  `CREDIT_CARD_REC` varchar(20) DEFAULT NULL,
  `CREDIT_EXP_DATE` varchar(15) DEFAULT NULL,
  `EARLY_ARRIVAL` varchar(2) DEFAULT NULL,
  `EARLY_ARRIVAL_DATE` date DEFAULT NULL,
  `EARLY_ARRIVAL_TIME` varchar(10) DEFAULT NULL,
  `WITH_GUEST` varchar(2) DEFAULT NULL,
  `GUEST_DINNER_DAY1` varchar(2) DEFAULT NULL,
  `GUEST_DINNER_DAY2` varchar(2) DEFAULT NULL,
  `DIETARY_RESTRICT` varchar(255) DEFAULT NULL,
  `REVISED_FULLNAME` varchar(80) DEFAULT NULL,
  `OCCUPANCY` varchar(20) DEFAULT NULL,
  `LAST_UPDATE_TS` int(11) DEFAULT NULL,
  `SELFREADY` int(11) DEFAULT NULL,
  `BOSSREADY` int(11) DEFAULT NULL,
  `PEERREADY` int(11) DEFAULT NULL,
  `CMS_STATUS` varchar(2) DEFAULT NULL,
  `CMS_FLAG` varchar(20) DEFAULT NULL,
  `Q18` int(11) DEFAULT NULL,
  `Q26` int(11) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_STATUS`
--

LOCK TABLES `PWI_STATUS` WRITE;
/*!40000 ALTER TABLE `PWI_STATUS` DISABLE KEYS */;
INSERT INTO `PWI_STATUS` VALUES ('731810','UERYHSMN',1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'731810 Brent Andersen',143092111,'Michael Pezel','AZ11','Sheraton Phoenix Airport Hotel',NULL,'2011-09-21','2011-09-21','2011-09-26','2011-09-26',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1334132572,NULL,NULL,NULL,'C','B',NULL,NULL),('731878','BGBXPGFE',21,1,1,1,1,1,1,1,1,NULL,NULL,1,9,1,1,'731878 Scott Schnaars',137111611,'Mike King','SC19','Newport Beach Marriott Bayview',NULL,'2012-06-01','2012-06-01','2012-05-11','2012-05-11',1,13,'Scott Schnaars','Mastercard',NULL,'7044948190679775','12/14','Y','2012-05-31','05:00 pm','N',NULL,NULL,'None','Mr. Scott Schnaars, Director','One Person',1334264208,NULL,NULL,NULL,'C','F',1,1),('732084','XBGEPMDN',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'732084 Barbara Bristol',137032112,'Lana Elliott','SC19','Newport Beach Marriott Bayview',NULL,'2012-03-21','2012-03-21','2012-03-12','2012-03-12',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1334132572,NULL,NULL,NULL,'S','O',NULL,NULL),('732048','FUZHDNRY',14,NULL,1,1,1,1,1,1,1,1,1,1,3,NULL,NULL,'732048 Brian Conway',137032112,'Lana Elliott','SC19','Newport Beach Marriott Bayview',NULL,'2012-03-21','2012-03-21','2012-03-14','2012-03-14',NULL,3,'Brian Conway','Mastercard',NULL,'61030431667127980','10/12','N',NULL,NULL,'N',NULL,NULL,'N/A',' Brian Conway, President','One Person',1334132572,NULL,NULL,NULL,'S','B',1,NULL);
/*!40000 ALTER TABLE `PWI_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_UPLOAD_ADMIN`
--

DROP TABLE IF EXISTS `PWI_UPLOAD_ADMIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_UPLOAD_ADMIN` (
  `ID` int(11) NOT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `IMPORT_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `EMP_TERM_DATE` datetime DEFAULT NULL,
  `INITIALS` varchar(6) DEFAULT NULL,
  `LAST_UPDATE_DT` datetime DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `ADMIN_NAME` varchar(80) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_UPLOAD_ADMIN`
--

LOCK TABLES `PWI_UPLOAD_ADMIN` WRITE;
/*!40000 ALTER TABLE `PWI_UPLOAD_ADMIN` DISABLE KEYS */;
INSERT INTO `PWI_UPLOAD_ADMIN` VALUES (231,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','TRK','0000-00-00 00:00:00','trking@mapconsulting.com','Timothy King'),(493,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','MAD','0000-00-00 00:00:00','madoty@mapconsulting.com','Melissa Doty'),(440,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','WWF','0000-00-00 00:00:00','wwfoxhoven@mapconsulting.com','Wendi Foxhoven'),(662,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','CMF','0000-00-00 00:00:00','cmforrest@mapconsulting.com','Cecelia Forrest'),(624,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','CTW','0000-00-00 00:00:00','ctwebb@mapconsulting.com','Catherine Webb'),(62,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','TMT','0000-00-00 00:00:00','tmtougas@mapconsulting.com','Tammy Tougas'),(693,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','BDC','0000-00-00 00:00:00','bdcruz@mapconsulting.com','Bethany Cruz'),(1048,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','KC','0000-00-00 00:00:00','kcooney@mapconsulting.com','Kathleen Cooney'),(767,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','VDR','0000-00-00 00:00:00','vrivera@mapconsulting.com','Vanessa Rivera'),(1049,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','MLB','0000-00-00 00:00:00','mlbelina@mapconsulting.com','Michelle Belina'),(791,100,'2006-06-09 04:08:36','0000-00-00 00:00:00','HDK','0000-00-00 00:00:00','hdking@mapconsulting.com','Holly King');
/*!40000 ALTER TABLE `PWI_UPLOAD_ADMIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_UPLOAD_EXEC`
--

DROP TABLE IF EXISTS `PWI_UPLOAD_EXEC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_UPLOAD_EXEC` (
  `ID` int(11) NOT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `IMPORT_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `EMP_TERM_DATE` datetime DEFAULT NULL,
  `INITIALS` varchar(6) DEFAULT NULL,
  `LAST_UPDATE_DT` datetime DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `FULLNAME` varchar(80) DEFAULT NULL,
  `JOB_DESC` varchar(80) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_UPLOAD_EXEC`
--

LOCK TABLES `PWI_UPLOAD_EXEC` WRITE;
/*!40000 ALTER TABLE `PWI_UPLOAD_EXEC` DISABLE KEYS */;
/*!40000 ALTER TABLE `PWI_UPLOAD_EXEC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_UPLOAD_LOCATION`
--

DROP TABLE IF EXISTS `PWI_UPLOAD_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_UPLOAD_LOCATION` (
  `ID` int(11) NOT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `IMPORT_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOC_CODE` varchar(12) DEFAULT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `CHECKIN` varchar(15) DEFAULT NULL,
  `RES_PHONE` varchar(20) DEFAULT NULL,
  `CITY` varchar(25) DEFAULT NULL,
  `FAX` varchar(20) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `ADDRESS` varchar(50) DEFAULT NULL,
  `ACTIVE` int(11) DEFAULT NULL,
  `ADMIN_FAX` varchar(20) DEFAULT NULL,
  `ZIP` varchar(15) DEFAULT NULL,
  `STATE` varchar(6) DEFAULT NULL,
  `LAST_UPDATE_DT` datetime DEFAULT NULL,
  `STATE_LONG` varchar(20) DEFAULT NULL,
  `PHONE` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_UPLOAD_LOCATION`
--

LOCK TABLES `PWI_UPLOAD_LOCATION` WRITE;
/*!40000 ALTER TABLE `PWI_UPLOAD_LOCATION` DISABLE KEYS */;
INSERT INTO `PWI_UPLOAD_LOCATION` VALUES (2,100,'2006-06-09 04:10:22','AZ01','Sheraton San Marcos','3_:__ _M','(602) 963-6655','Chandler','','','One San Marcos Place',0,'(818) 981-8017','85224','AZ','2004-05-19 15:28:17','Arizona','(602) 963-6655'),(3,100,'2006-06-09 04:10:22','AZ02','Embassy Suites Hotel-AZ','3_:__ _M','(602) 375-1777','Phoenix','','','2577 West Greenway Road',0,'(818) 981-8017','85023','AZ','2004-05-19 15:28:17','Arizona','(602) 375-1777'),(4,100,'2006-06-09 04:10:22','AZ03','Arizona Biltmore','','602-955-6600','Phoenix','','','24th Street and Missouri',0,'(818) 981-8017','85016-','AZ','2004-05-19 15:28:17','Arizona','602-955-6600'),(5,100,'2006-06-09 04:10:22','AZ04','Sheraton Crescent Hotel','','(602) 943-8200','Phoenix','','','2620 West Dunlap Avenue',0,'(818) 981-8017','85021','AZ','2004-05-19 15:28:17','Arizona','(602) 943-8200'),(7,100,'2006-06-09 04:10:22','AZ06','Carefree Conference Rsrt','','480-488-5300','Carefree','','','37220 Mule Train Road',0,'(818) 981-8017','85377-','AZ','2004-05-19 15:28:17','Arizona','480-488-5300'),(8,100,'2006-06-09 04:10:22','AZ07','Scottsdale Conference Rst','','800-528-0293','Scottsdale','','','7700 East McCormick Parkway',0,'(818) 981-8017','85258-','AZ','2004-05-19 15:28:17','Arizona','800-528-0293'),(9,100,'2006-06-09 04:10:22','AZ08','Bank One Ballpark','','(602) 462-6000','Phoenix','','','401 East Jefferson Street',0,'(818) 981-8017','85004-2438','AZ','2004-05-19 15:28:17','Arizona','(602) 462-6000'),(10,100,'2006-06-09 04:10:22','HI01','Ala Moana Hotel','','-   -','Honolulu','','','410 Atkinson Drive',0,'(818) 981-8017','96814-4722','HI','2004-05-19 15:28:17','Hawaii','-   -'),(11,100,'2006-06-09 04:10:22','LV01','MAP','','(702) 736-7111','Las Vegas','(702) 736-7171','lwhall@mapconsulting.com','2215 B3 Renaissance Dr.',0,'(818) 981-8017','89119','NV','2004-05-19 15:28:17','Nevada','(702) 736-7111'),(12,100,'2006-06-09 04:10:22','LV02','Mt. Charleston Hotel','','(702) 872-5500','Mt. Charleston','','','Kyle Canyon Road',0,'(818) 981-8017','89124','NV','2004-05-19 15:28:17','Nevada','(702) 872-5500'),(13,100,'2006-06-09 04:10:22','LV03','St. Tropez Suite Hotel','','(702) 369-5400','Las Vegas','','','455 East Harmon Boulevard',0,'(818) 981-8017','89109','NV','2004-05-19 15:28:17','Nevada','(702) 369-5400'),(14,100,'2006-06-09 04:10:22','LV04','Casablanca Resort Hotel','10:0_ _M','(702) 346-7529','Mesquite','','','950 W Mesquite Blvd.',0,'(818) 981-8017','89027','NV','2004-05-19 15:28:17','Nevada','(702) 346-7529'),(15,100,'2006-06-09 04:10:22','LV05','Eureka Hotel & Casino','02:00 PM','(800) 346-4611','Mesquite','(702) 346-4680','sslak@eureka-mesquite.com','275 Mesa Blvd.',0,'(818) 981-8017','89027','NV','2004-05-19 15:28:17','Nevada','(702) 346-4646'),(16,100,'2006-06-09 04:10:22','M501','Test MAP II Site','','818-380-1177','Sherman Oaks','','','1234 Avenue',0,'(818) 981-8017','91423-','CA','2004-05-19 15:28:17','California','818-380-1177'),(17,100,'2006-06-09 04:10:22','MT01','Cavanaughs Colonial Hotel','','406-443-2100','Helena','','','2301 Colonial Drive',0,'(818) 981-8017','59601-','MT','2004-05-19 15:28:17','Montana','406-443-2100'),(18,100,'2006-06-09 04:10:22','MT03','Rainbow Ranch Lodge','01:00 PM','(702) 736-7111','Gallatin Gateway','(702) 736-7171','jackie@rainbowranch.com','42950 Gallatin Road',0,'(818) 981-8017','59730','MT','2004-05-19 15:28:17','Montana','(702) 736-7111'),(19,100,'2006-06-09 04:10:22','NC01','Westin Hotel @ SF Airport','','650-692-3500','Millbrae','','','1 Old Bayshore Highway',0,'(818) 981-8017','94030-','CA','2004-05-19 15:28:17','California','650-692-3500'),(20,100,'2006-06-09 04:10:22','NC03','Claremont Resort','1PM','415-549-8520','Oakland','','','Ashby & Domingo Avenues',0,'(818) 981-8017','94623-0363','CA','2004-05-19 15:28:17','California','415-549-8520'),(21,100,'2006-06-09 04:10:22','NC04','Sheraton Suites','','954-424-3300','Plantation','','','311 North University Drive',0,'(818) 981-8017','33324-','FL','2004-05-19 15:28:17','Florida','954-424-3300'),(22,100,'2006-06-09 04:10:22','NC05','Embassy Suites','4:30','530-544-5400','South Lake Tahoe','','','Resort Lake Tahoe',0,'(818) 981-8017','96150-6965','CA','2004-05-19 15:28:17','California','530-544-5400'),(23,100,'2006-06-09 04:10:22','NC06','Sheraton Pleasanton','','415-460-8800','Pleasanton','','','5115 Hopyard Road',0,'(818) 981-8017','94566-','CA','2004-05-19 15:28:17','California','415-460-8800'),(24,100,'2006-06-09 04:10:22','NC07','Embassy Suites Hotel','12:01 PM','(707) 253-9540','Napa','(707) 253-9202','','1075 California Boulevard',0,'(818) 981-8017','94559','CA','2004-05-19 15:28:17','California','(707) 253-9540'),(25,100,'2006-06-09 04:10:22','NC08','Monterey Beach Hotel','4 PM','831-394-3321','Monterey','','','2600 Sand Dunes Drive',0,'(818) 981-8017','93940-','CA','2004-05-19 15:28:17','California','831-394-3321'),(26,100,'2006-06-09 04:10:22','NC09','Hotel Sofitel','','415-598-9000','Redwood City','','','223 Twin Dolphin Drive',0,'(818) 981-8017','94065-','CA','2004-05-19 15:28:17','California','415-598-9000'),(27,100,'2006-06-09 04:10:22','NC10','Embassy Suites','','','Milpitas','','','',0,'(818) 981-8017','','CA','2004-05-19 15:28:17','California',''),(28,100,'2006-06-09 04:10:22','NC11','Napa Valley Marriott','03:00 PM','(707) 253-7433','Napa','(707) 258-1320','','3425 Solano Avenue',0,'(818) 981-8017','94558','CA','2004-05-19 15:28:17','California','(707) 253-7433'),(29,100,'2006-06-09 04:10:22','NC12','Marriott\'s Tenaya Lodge','','209-683-6555','Fish Camp','','','1122 Highway 41',0,'(818) 981-8017','93623-','CA','2004-05-19 15:28:17','California','209-683-6555'),(30,100,'2006-06-09 04:10:22','NC13','Sheraton','','916-638-1100','Rancho Cordova','','','11211 Point East Drive',0,'(818) 981-8017','95742-','CA','2004-05-19 15:28:17','California','916-638-1100'),(31,100,'2006-06-09 04:10:22','NC14','Westin Hotel','','415-692-3500','Millbrae','','','1 Old Bayshore Highway',0,'(818) 981-8017','94030-','CA','2004-05-19 15:28:17','California','415-692-3500'),(32,100,'2006-06-09 04:10:22','NC17','Embassy Suites','','415-934-2500','Walnut Creek','','','1345 Treat Boulevard',0,'(818) 981-8017','94596-','CA','2004-05-19 15:28:17','California','415-934-2500'),(33,100,'2006-06-09 04:10:22','NC18','Red Lion Inn','','707-584-5466','Rohnert Park','','','One Red Lion Drive',0,'(818) 981-8017','94928-','CA','2004-05-19 15:28:17','California','707-584-5466'),(34,100,'2006-06-09 04:10:22','NC21','Embassy Suites','','415-499-9222','San Rafael','','','101 McInnis Parkway',0,'(818) 981-8017','94903-','CA','2004-05-19 15:28:17','California','415-499-9222'),(35,100,'2006-06-09 04:10:22','NC22','Red Lion Hotel','','408-453-4000','San Jose','','','2050 Gateway Place',0,'(818) 981-8017','95110-','CA','2004-05-19 15:28:17','California','408-453-4000'),(36,100,'2006-06-09 04:10:22','NC23','Courtyard Marriott','','-   -','Rancho Cordova','','','10683 Whiterock Road',0,'(818) 981-8017','95670-','CA','2004-05-19 15:28:17','California','-   -'),(37,100,'2006-06-09 04:10:22','NC24','Red Lion','','-   -','Sacramento','','','',0,'(818) 981-8017','-','CA','2004-05-19 15:28:17','California','-   -'),(39,100,'2006-06-09 04:10:22','NW01','MAP, Inc.','','206-453-0377','Bellevue','','','12011 NE 1st Street, Suite 309',0,'(818) 981-8017','98005-','WA','2004-05-19 15:28:17','Washington','206-453-0377'),(40,100,'2006-06-09 04:10:22','NW02','Westmark Hotel','','907-276-7676','Anchorage','','','720 West 5th Avenue',0,'(818) 981-8017','99501-','AK','2004-05-19 15:28:17','Alaska','907-276-7676'),(41,100,'2006-06-09 04:10:22','NW03','WestCoast Bellevue Hotel','4pm','425-455-9444','Bellevue','','','625 116th Avenue NE',0,'(818) 981-8017','98004-','WA','2004-05-19 15:28:17','Washington','425-455-9444'),(42,100,'2006-06-09 04:10:22','NW04','Red Lion Bellevue Inn','4_:__ _M','(425) 455-5240','Bellevue','','','11211 Main Street',0,'(818) 981-8017','98004','WA','2004-05-19 15:28:17','Washington','(425) 455-5240'),(43,100,'2006-06-09 04:10:22','NW05','Columbia Gorge Hotel','','503-386-5566','Hood River','','','4000 Westcliff Drive',0,'(818) 981-8017','97031-','OR','2004-05-19 15:28:17','Oregon','503-386-5566'),(44,100,'2006-06-09 04:10:22','NW06','Salish Lodge','','800-826-6124','Snoqualmie','','','6501 Railroad Avenue Southeast',0,'(818) 981-8017','98065-','WA','2004-05-19 15:28:17','Washington','800-826-6124'),(45,100,'2006-06-09 04:10:22','NW07','Hyatt Regency Bellevue','12:00 PM','(425) 698-4254','Bellevue','(425) 698-4281','','900 Bellevue Way Northeast',0,'(818) 981-8017','98004','WA','2004-05-19 15:28:17','Washington','(425) 462-1234'),(46,100,'2006-06-09 04:10:22','NW08','Park Plaza Hotel','','406-443-2200','Helena','','','22 N. Last Chance Gulch',0,'(818) 981-8017','59601-','MT','2004-05-19 15:28:17','Montana','406-443-2200'),(47,100,'2006-06-09 04:10:22','NW09','Riverplace Hotel','12pm','503-228-3233','Portland','','','1510 Southwest Harbor Way',0,'(818) 981-8017','97201-','OR','2004-05-19 15:28:17','Oregon','503-228-3233'),(48,100,'2006-06-09 04:10:22','NW10','Best Western Southcenter','12N','425-226-1812','Seattle','','','15901 West Valley Road',0,'(818) 981-8017','98188-','WA','2004-05-19 15:28:17','Washington','425-226-1812'),(49,100,'2006-06-09 04:10:22','NW11','Wyndham Garden Hotel','2PM','425-485-5557','Bothell','','','19333 North Creek Parkway',0,'(818) 981-8017','98011-','WA','2004-05-19 15:28:17','Washington','425-485-5557'),(50,100,'2006-06-09 04:10:22','NW12','Mat-Su Resort','','','Wasilla','','','',0,'(818) 981-8017','','AK','2004-05-19 15:28:17','Alaska',''),(51,100,'2006-06-09 04:10:22','NW13','Clarion Hotel','','907-243-2300','Anchorage','','','4800 Spenard Road',0,'(818) 981-8017','99517-3236','AK','2004-05-19 15:28:17','Alaska','907-243-2300'),(52,100,'2006-06-09 04:10:22','NW14','Doubletree Suites','','','','','','',0,'(818) 981-8017','','WA','2004-05-19 15:28:17','Washington',''),(53,100,'2006-06-09 04:10:22','NW16','Inn At Semi-Ah-Moo','0','206-371-2000','Blaine','','','P.O. Box 790',0,'(818) 981-8017','98230-0790','WA','2004-05-19 15:28:17','Washington','206-371-2000'),(54,100,'2006-06-09 04:10:22','NW17','Woodmark Hotel','','206-822-3700','Kirkland','','','1200 Carillon Point',0,'(818) 981-8017','98033-','WA','2004-05-19 15:28:17','Washington','206-822-3700'),(55,100,'2006-06-09 04:10:22','NW18','Marriott Suites','','708-290-1600','Elk Grove Village','','','121 Northwest Point Blvd.',0,'(818) 981-8017','60007-','IL','2004-05-19 15:28:17','Illinois','708-290-1600'),(56,100,'2006-06-09 04:10:22','NW19','Coeur d\'Alene Resort','','208-765-4000','Coeur d\'Alene','','','P. O. Box 7200',0,'(818) 981-8017','83814-','ID','2004-05-19 15:28:17','Idaho','208-765-4000'),(57,100,'2006-06-09 04:10:22','OO01','Bellevue Hilton Inn','','206-455-3330','Bellevue','','','100 112th Avenue Northeast',0,'(818) 981-8017','98004-','WA','2004-05-19 15:28:17','Washington','206-455-3330'),(58,100,'2006-06-09 04:10:22','OR01','Embassy Suites Downtown','','503-796-3851','Portland','','','319 Southwest Pine Street',0,'(818) 981-8017','97204-','OR','2004-05-19 15:28:17','Oregon','503-796-3851'),(59,100,'2006-06-09 04:10:22','OR02','Crown Plaza Hotel','03:00 PM','(503) 624-8400','Lake Oswego','','cheri.crowne@verizon.net','14811 Cruse Oaks Drive',0,'(818) 981-8017','97035','OR','2004-05-19 15:28:17','Oregon','(503) 624-8400'),(60,100,'2006-06-09 04:10:22','R101','Radisson Hotel','','818-981-5400','Sherman Oaks','','','15433 Ventura Boulevard',0,'(818) 981-8017','91403-','CA','2004-05-19 15:28:17','California','818-981-5400'),(61,100,'2006-06-09 04:10:22','R102','MAP, Inc.','','818-380-1177','Sherman Oaks','','','4725 Hazeltine Avenue',0,'(818) 981-8017','91423-','CA','2004-05-19 15:28:17','California','818-380-1177'),(62,100,'2006-06-09 04:10:22','R103','MAP','','702-736-7111','Las Vegas','','','2215 B-3 Renaissance Drive',0,'(818) 981-8017','89119-','NV','2004-05-19 15:28:17','Nevada','702-736-7111'),(63,100,'2006-06-09 04:10:22','R201','MAP Office','','510-847-9191','Pleasanton','','','5820 Stoneridge Mall Road, #100',0,'(818) 981-8017','94588-','CA','2004-05-19 15:28:17','California','510-847-9191'),(64,100,'2006-06-09 04:10:22','R202','HQ San Francisco','','415-674-4000','San Francisco','','','Two Embarcadero Center, 2nd Floor',0,'(818) 981-8017','94111-','CA','2004-05-19 15:28:17','California','415-674-4000'),(65,100,'2006-06-09 04:10:22','R203','Westin Hotel @ SF Airport','0','650-692-3500','Millbrae','','','1 Old Bayshore Highway',0,'(818) 981-8017','94030-','CA','2004-05-19 15:28:17','California','650-692-3500'),(66,100,'2006-06-09 04:10:22','R204','Autumn Moon Cafe','','510-595-3200','Oakland','','','3909 Grand Avenue',0,'(818) 981-8017','94610-','CA','2004-05-19 15:28:17','California','510-595-3200'),(67,100,'2006-06-09 04:10:22','R301','Bellevue Conference Ctr.','','425-451-9995','Bellevue','','','121 107th Avenue NE',0,'(818) 981-8017','98004-','WA','2004-05-19 15:28:17','Washington','425-451-9995'),(68,100,'2006-06-09 04:10:22','R302','MAP Bellevue Office','','425-453-0377','Bellevue','','','12011 Northeast 1st Street',0,'(818) 981-8017','98005-','WA','2004-05-19 15:28:17','Washington','425-453-0377'),(69,100,'2006-06-09 04:10:22','R303','Park Plaza Hotel','','406-443-2200','Helena','','','22 N. Last Chance Gulch',0,'(818) 981-8017','59601-','MT','2004-05-19 15:28:17','Montana','406-443-2200'),(70,100,'2006-06-09 04:10:22','R304','Cavanaughs Colonial Hotel','1:00','406-443-2100','Helena','','','2301 Colonial Drive',0,'(818) 981-8017','59601-','MT','2004-05-19 15:28:17','Montana','406-443-2100'),(71,100,'2006-06-09 04:10:22','R305','Rainbow Ranch Lodge','12N','406-995-4132','Gallatin Gateway','','','42950 Gallatin Road',0,'(818) 981-8017','59730-','MT','2004-05-19 15:28:17','Montana','406-995-4132'),(72,100,'2006-06-09 04:10:22','R310','TBA','','425-453-0377','Spokane','','','',0,'(818) 981-8017','-','WA','2004-05-19 15:28:17','Washington','425-453-0377'),(73,100,'2006-06-09 04:10:22','R311','TBA','','425-453-0377','Portland','','','',0,'(818) 981-8017','-','OR','2004-05-19 15:28:17','Oregon','425-453-0377'),(74,100,'2006-06-09 04:10:22','R312','Cavanaugh\'s at the Park','','-   -','Spokane','','','',0,'(818) 981-8017','-','WA','2004-05-19 15:28:17','Washington','-   -'),(75,100,'2006-06-09 04:10:22','R401','Balboa Bay Club','','714-645-5000','Newport Beach','','','1221 W. Coast Highway',0,'(818) 981-8017','92660-','CA','2004-05-19 15:28:17','California','714-645-5000'),(76,100,'2006-06-09 04:10:22','R402','MAP Newport Beach','','949-752-1606','Newport Beach','','','4299 MacArthur Boulevard, Ste. 102',0,'(818) 981-8017','92660-','CA','2004-05-19 15:28:17','California','949-752-1606'),(77,100,'2006-06-09 04:10:22','R403','Location to be determined','','(818) 380-1170','Salt Lake City','','','TBD',0,'(818) 981-8017','84092','UT','2004-05-19 15:28:17','Utah',''),(78,100,'2006-06-09 04:10:22','R601','MAP TX Office','','214-265-6551','Dallas','','','7557 Rambler Road, Suite 700',0,'(818) 981-8017','75231-','TX','2004-05-19 15:28:17','Texas','214-265-6551'),(79,100,'2006-06-09 04:10:22','R701','MAP AZ Office','','602-279-7700','Phoenix','','','4747 North 7th Street, Suite 302',0,'(818) 981-8017','85014-','AZ','2004-05-19 15:28:17','Arizona','602-279-7700'),(80,100,'2006-06-09 04:10:22','R702','Embassy Suites Hotel','','602-375-1777','Phoenix','','','2577 West Greenway Road',0,'(818) 981-8017','85023-','AZ','2004-05-19 15:28:17','Arizona','602-375-1777'),(81,100,'2006-06-09 04:10:22','R703','Arizona Country Club','','480-947-7666','Phoenix','','','5668 East Orange Blossom Lane',0,'(818) 981-8017','85018-','AZ','2004-05-19 15:28:17','Arizona','480-947-7666'),(82,100,'2006-06-09 04:10:22','R801','MAP San Diego','','-   -','San Diego','','','',0,'(818) 981-8017','-','CA','2004-05-19 15:28:17','California','-   -'),(83,100,'2006-06-09 04:10:22','SC01','Gold Canyon Ranch','','602-982-9090','Apache Junction','','','6100 South Kings Ranch Road',0,'(818) 986-1217','85219-','AZ','2004-05-19 15:28:17','Arizona','602-982-9090'),(84,100,'2006-06-09 04:10:22','SC02','Balboa Bay Club','15','949-645-5000','Newport Beach','','','1221 West Pacific Coast Highway',0,'(818) 986-1217','92663-','CA','2004-05-19 15:28:17','California','949-645-5000'),(85,100,'2006-06-09 04:10:22','SC03','The Sutton Place Hotel','3:00','714-476-2001','Newport Beach','','','4500 MacArthur Boulevard',0,'(818) 986-1217','92660-','CA','2004-05-19 15:28:17','California','714-476-2001'),(86,100,'2006-06-09 04:10:22','SC04','Embassy Suites Hotel','3:00','714-241-3800','Santa Ana','','','1325 East Dyer Road',0,'(818) 986-1217','92705-','CA','2004-05-19 15:28:17','California','714-241-3800'),(87,100,'2006-06-09 04:10:22','SC05','So. Cal. location TBD','','','Newport Beach','','','4299 MacArthur Boulevard, Suite 102',0,'(818) 986-1217','92660','CA','2004-05-19 15:28:17','California',''),(88,100,'2006-06-09 04:10:22','SC06','Wyndham Garden Hotel','16','714-751-5100','Costa Mesa','','','3350 Avenue of the Arts',0,'(818) 986-1217','92626-','CA','2004-05-19 15:28:17','California','714-751-5100'),(89,100,'2006-06-09 04:10:22','SC07','Country Side Inn & Suites','03:__ PM','(714) 549-0300','Costa Mesa','','','325 Bristol Street',0,'(818) 986-1217','92626','CA','2004-05-19 15:28:17','California','(714) 549-0300'),(90,100,'2006-06-09 04:10:22','SC08','Warner Center Marriott','3:00','818-887-4800','Woodland Hills','','','21850 Oxnard Street',0,'(818) 986-1217','91367-','CA','2004-05-19 15:28:17','California','818-887-4800'),(91,100,'2006-06-09 04:10:22','SC09','Park Hyatt Los Angeles','3:00','310-277-1234','Los Angeles','','','2151 Avenue of the Stars',0,'(818) 986-1217','90067-','CA','2004-05-19 15:28:17','California','310-277-1234'),(92,100,'2006-06-09 04:10:22','SC10','Hyatt Newporter Inn','4:00','714-729-1234','Newport Beach','','','1107 Jamboree Road',0,'(818) 986-1217','92660-','CA','2004-05-19 15:28:17','California','714-729-1234'),(94,100,'2006-06-09 04:10:22','SC12','Ritz Carlton','1:00','','Rancho Mirage','','','68900 Frank Sinatra Boulevard',0,'(818) 986-1217','92270-','CA','2004-05-19 15:28:17','California',''),(95,100,'2006-06-09 04:10:22','SC13','Portofino Inn','','213-379-8481','Redondo Beach','','','260 Portofino Way',0,'(818) 986-1217','90277-2092','CA','2004-05-19 15:28:17','California','213-379-8481'),(96,100,'2006-06-09 04:10:22','SC14','Doubletree Hotel','','213-301-3000','Marina del Rey','','','4100 Admiralty Way',0,'(818) 986-1217','90292-','CA','2004-05-19 15:28:17','California','213-301-3000'),(97,100,'2006-06-09 04:10:22','SC15','Pala Mesa Resort','','619-728-5881','Fallbrook','','','2001 Old Highway 395',0,'(818) 986-1217','92028-','CA','2004-05-19 15:28:17','California','619-728-5881'),(98,100,'2006-06-09 04:10:22','SC16','Radisson Newport Beach','06:0_ PM','(949) 833-0570','Newport Beach','','','4545 MacArthur Boulevard',0,'(818) 986-1217','92660','CA','2004-05-19 15:28:17','California','(949) 833-0570'),(99,100,'2006-06-09 04:10:22','SC17','WestCoast Long Beach','3:00','562-435-7676','Long Beach','','','700 Queensway Drive',0,'(818) 986-1217','90802-','CA','2004-05-19 15:28:17','California','562-435-7676'),(103,100,'2006-06-09 04:10:22','SC99','San Diego Area','','','San Diego','','','',0,'(818) 986-1217','','CA','2004-05-19 15:28:17','California',''),(104,100,'2006-06-09 04:10:22','TX01','Arlington Marriot Hotel','','-   -','Arlington','','','1500 Convention Center Drive',0,'(818) 981-8017','76011-','TX','2004-05-19 15:28:17','Texas','-   -'),(105,100,'2006-06-09 04:10:22','TX02','Marriott Solana','3:00','817-430-3848','Westlake','','','5 Village Circle',0,'(818) 981-8017','76262-','TX','2004-05-19 15:28:17','Texas','817-430-3848'),(106,100,'2006-06-09 04:10:22','TX03','The Harvey Hotel & Suites','','972-929-4500','Irving','','','4545 John Carpenter Freeway',0,'(818) 981-8017','75063-','TX','2004-05-19 15:28:17','Texas','972-929-4500'),(107,100,'2006-06-09 04:10:23','TX04','Crowne Plaza Hotel-Resort','','(972) 980-8877','Addison','','','14315 Midway Road',0,'(818) 981-8017','75001','TX','2004-05-19 15:28:17','Texas','(972) 980-8877'),(108,100,'2006-06-09 04:10:23','TX05','Double Tree Hotel Dallas','','214-691-8700','Dallas','','','8250 North Central Expressway',0,'(818) 981-8017','75206-','TX','2004-05-19 15:28:17','Texas','214-691-8700'),(109,100,'2006-06-09 04:10:23','UT01','Cavanaugh\'s Olympus Hotel','3pm','801-521-7373','Salt Lake City','','','161 West 600 South',0,'(818) 981-8017','84101-','UT','2004-05-19 15:28:17','Utah','801-521-7373'),(110,100,'2006-06-09 04:10:23','UT02','Radisson Hotel Park City','02:00 PM','(435) 649-5000','Park City','','','2121 Park Avenue',0,'(818) 981-8017','84060','UT','2004-05-19 15:28:17','Utah','(435) 649-5000'),(111,100,'2006-06-09 04:10:23','UT03','Larry Miller Center, SLCC','1:00','801-957-5200','Sandy','','','9750 South 300 West',0,'(818) 981-8017','84070-','UT','2004-05-19 15:28:17','Utah','801-957-5200'),(112,100,'2006-06-09 04:10:23','WE01','Washington Employers Assoc.','03:00 PM','(206) 329-1120','Kent','(206) 328-0131','','24437 Russell Road, Suite 110',0,'(818) 981-8017','98032','WA','2004-05-19 15:28:17','Washington','(206) 329-1120'),(113,100,'2006-06-09 04:10:23','Z101','MAP-Sherman Oaks','0','818-380-1177','Sherman Oaks','','','4725 Hazeltine Avenue',0,'(818) 981-8017','91423-','CA','2004-05-19 15:28:17','California','818-380-1177'),(114,100,'2006-06-09 04:10:23','Z201','Autumn Moon Cafe','','510-595-3200','Oakland','','','3909 Grand Avenue',0,'(818) 981-8017','94610-','CA','2004-05-19 15:28:17','California','510-595-3200'),(115,100,'2006-06-09 04:10:23','Z801','MAP-Nevada','1:00','702-736-7111','Las Vegas','','','2215 Renaissance Dr., Ste. B3',0,'(818) 981-8017','89119-','NV','2004-05-19 15:28:17','Nevada','702-736-7111'),(117,100,'2006-06-09 04:10:23','TX06','Hilton Dallas/Park Cities','03:00 PM','','Dallas','(214) 691-3157','','5954 Luther Lane',0,'(818) 981-8017','75225','TX','2004-05-19 15:28:17','Texas','(214) 368-0400'),(118,100,'2006-06-09 04:10:23','LV06','Alexis Park Resort','02:00 PM','(800) 582-2228','Las Vegas','(702) 796-0766','sgratton@alexispark.com','375 Harmon Blvd.',0,'(818) 981-8017','89109','NV','2004-05-19 15:28:17','Nevada','(702) 796-3397'),(119,100,'2006-06-09 04:10:23','MTR01','Envirocon, Inc. (MAP II)','01:00 PM','(702) 736-7111','Missoula','(702) 736-7171','lwhall@mapconsulting.com','500 Taylor St., PO Box 16655',0,'(818) 981-8017','59808','MT','2004-05-19 15:28:17','Montana','(702) 736-7111'),(120,100,'2006-06-09 04:10:23','AZ09','Doubletree Guest Suites - Phx','','(602) 225-0500','Phoenix','(602) 231-0561','','320 North 44th Street',0,'(818) 981-8017','85008','AZ','2004-05-19 15:28:17','Arizona','(602) 225-0500'),(122,100,'2006-06-09 04:10:23','LV10','JW Marriott Resort/Spa','02:00 PM','(702) 736-7111','Las Vegas','(702) 796-8376','dana.epley@marriott.com','221 N Rampart Blvd.',0,'(818) 981-8017','89145','NV','2004-05-19 15:28:17','Nevada','(702) 869-7777'),(123,100,'2006-06-09 04:10:23','NC02','MAP Oakland','','','Oakland','','mspezel@mapconsulting.com','300 Frank H. Ogawa Plaza, Suite 210',0,'(818) 981-8017','94612','CA','2004-05-19 15:28:17','California',''),(124,100,'2006-06-09 04:10:23','MTR02','Missoula Family YMCA','01:00 PM','(702) 736-7111','Missoula','(406) 721-9226','','3000 S Russell',0,'(818) 981-8017','59801','MT','2004-05-19 15:28:17','Montana','(406) 721-9622'),(125,100,'2006-06-09 04:10:23','LV11','Boulder Station Hotel & Casino','03:00 PM','(702) 736-7111','Las Vegas','(702) 432-7506','shar.costello@stationcasinos.com','4111 Boulder Highway',0,'(818) 981-8017','89121','NV','2004-05-19 15:28:17','Nevada','(702) 432-7777'),(126,100,'2006-06-09 04:10:23','LV12','AGC of Georgia','10:00 AM','(702) 736-7111','Atlanta','(678) 298-4101','latham@agcga.org','1940 The Exchange',0,'(818) 981-8017','30339-2002','GA','2004-05-19 15:28:17','Georgia','(800) 203-4629'),(127,100,'2006-06-09 04:10:23','UT04','The Homestead','04:00 PM','(702) 736-7111','Midway','(435) 654-5087','kathy.grieve@homesteadresort.com','700 N Homestead Dr.',0,'(818) 981-8017','84049','UT','2004-05-19 15:28:17','Utah','(800) 327-7220'),(129,100,'2006-06-09 04:10:23','WE02','Best Wstrn. Plaza on the Green','03:00 PM','(253) 854-8767','Kent','(253) 850-7667','sandrabwpg@hotmail.com','24115 Russell Road',0,'(818) 981-8017','98032','WA','2004-05-19 15:28:17','Washington','(253) 854-8767'),(130,100,'2006-06-09 04:10:23','LV13','Las Vegas MAPII Location','12:00 AM','(702) 798-7344','Las Vegas','','','1055 East Tropicana, Suite 250',0,'(818) 981-8017','89119','NV','2004-05-19 15:28:17','Nevada',''),(131,100,'2006-06-09 04:10:23','Z102','Empire Companies','10:00 AM','(909) 987-7788','Ontario','(909) 980-7305','','3536 Concours St., Suite 300',0,'(818) 981-8017','91764','CA','2004-05-19 15:28:17','California',''),(132,100,'2006-06-09 04:10:23','UT05','Hidden Valley Country Club','02:00 PM','(801) 571-0583','Salt Lake City','','','11820 South Highland Drive',0,'(818) 981-8017','84092','UT','2004-05-19 15:28:17','Utah','(801) 551-1151'),(133,100,'2006-06-09 04:10:23','UT06','Best Western - Cotton Tree Inn','02:00 PM','(801) 523-8484','South Jordan','','','10695 South Auto Mall Drive',0,'(818) 981-8017','84070','UT','2004-05-19 15:28:17','Utah',''),(134,100,'2006-06-09 04:10:23','UT07','Utah-location to be determined','02:00 PM','','To be determined','','','To be determined',0,'(818) 981-8017','85072','UT','2004-05-19 15:28:17','Utah',''),(135,101,'2006-06-09 04:10:23','SC00','S.O. - In House MAPII Programs','00:00 PM','(818) 380-1177','0000','','CTWEBB@MAPCONSULTING.COM','0000',0,'','91423','CA','2004-11-23 11:33:58','California',''),(100,101,'2006-06-09 04:10:23','SC18','Marriott Hotel & Tennis Club','','(949) 640-4000','Newport Beach','','','900 Newport Center Drive',0,'(818) 986-1217','92660','CA','2004-12-08 14:47:14','California','(949) 640-4000'),(101,101,'2006-06-09 04:10:23','SC19','Marriott Suites, Newport','06:0_ PM','(949) 854-4500','Newport Beach','','','500 Bayview Circle',0,'(818) 986-1217','92660','CA','2004-12-08 14:50:36','California','(949) 854-4500'),(121,101,'2006-06-09 04:10:23','SC21','Irvine Marriott','03:00 PM','(949) 553-0100','Irvine','(949) 261-7059','','18000 Von Karman Avenue',0,'(818) 986-1217','92612','CA','2004-12-08 14:51:46','California','(949) 533-0100'),(102,101,'2006-06-09 04:10:23','SC20','Costa Mesa Marriott Suites','06:0_ PM','','Costa Mesa','','','500 Anton Boulevard',0,'(818) 986-1217','92626','CA','2005-01-14 10:21:03','California',''),(136,101,'2006-06-09 04:10:23','WE03','Marriott-Lake Union Courtyard','03:00 PM','(800) 359-7916','Seattle','(206) 260-8928','Erin.Potucek@marriott.com','925 Westlake Avenue North',0,'','98109','WA','2005-05-04 10:51:51','Washington','(206) 213-0100'),(128,101,'2006-06-09 04:10:23','NC15','Hilton Garden Inn','04:00 PM','(707) 252-0444','Napa','(707) 252-0244','kay_eardley@hilton.com','3585 Solano Avenue',0,'(818) 981-8017','94558','CA','2005-05-05 09:21:12','California','(707) 252-0444'),(6,101,'2006-06-09 04:10:23','AZ05','Gold Canyon Golf Resort','04:00 PM','(480) 671-5546','Gold Canyon','','','6100 South Kings Ranch Road',0,'(818) 981-8017','85219','AZ','2005-05-11 09:41:36','Arizona','(480) 671-5546');
/*!40000 ALTER TABLE `PWI_UPLOAD_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_UPLOAD_PARTICIPANT`
--

DROP TABLE IF EXISTS `PWI_UPLOAD_PARTICIPANT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_UPLOAD_PARTICIPANT` (
  `ID` int(11) NOT NULL,
  `SALUTATION` varchar(25) DEFAULT NULL,
  `LASTNAME` varchar(25) DEFAULT NULL,
  `FIRSTNAME` varchar(25) DEFAULT NULL,
  `TITLE` varchar(50) DEFAULT NULL,
  `COMPANY` varchar(70) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `SEX` char(1) DEFAULT NULL,
  `PAR_LAST_UPDATE_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CST_LAST_UPDATE_DT` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `BOSSLASTNAME` varchar(25) DEFAULT NULL,
  `BOSSFIRSTNAME` varchar(25) DEFAULT NULL,
  `BOSSID` int(11) DEFAULT NULL,
  `BOSSEMAIL` varchar(50) DEFAULT NULL,
  `CMS_STATUS` char(1) DEFAULT NULL,
  `STARTDATE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LOCATIONCODE` varchar(6) DEFAULT NULL,
  `LOCATION` varchar(30) DEFAULT NULL,
  `LOCATIONADDRESS` varchar(50) DEFAULT NULL,
  `LOCATIONSTATE` varchar(30) DEFAULT NULL,
  `LOCATIONCITY` varchar(25) DEFAULT NULL,
  `HOTELRATE` float DEFAULT NULL,
  `EXECNAME` varchar(25) DEFAULT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `IMPORT_DT` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_UPLOAD_PARTICIPANT`
--

LOCK TABLES `PWI_UPLOAD_PARTICIPANT` WRITE;
/*!40000 ALTER TABLE `PWI_UPLOAD_PARTICIPANT` DISABLE KEYS */;
INSERT INTO `PWI_UPLOAD_PARTICIPANT` VALUES (717572,'Mr.','Gray','Randy','Vice President','Pyramid Builders','ac@market-research.com','M','2005-06-06 06:11:31','2005-03-29 07:00:08','Murphy','Michael',717571,'mikkel@market-research.com','C','2003-06-10 14:00:00','SC19','Marriott Suites, Newport','500 Bayview Circle','CA','Newport Beach',625,'Michael Stanko',100,'2006-06-09 04:18:13'),(717588,'Mr.','Snyder','Craig','Chief Financial Offecer','Metal Surfaces, Incorporated','mikkel@market-research.com','M','2005-06-06 06:11:31','2005-03-29 07:00:08','Ledterman','Bob',717435,'ac@market-research.com','C','2003-06-10 14:00:00','SC19','Marriott Suites, Newport','500 Bayview Circle','CA','Newport Beach',625,'Ed Stein',100,'2006-06-09 04:18:13');
/*!40000 ALTER TABLE `PWI_UPLOAD_PARTICIPANT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_UPLOAD_WORKSHOP`
--

DROP TABLE IF EXISTS `PWI_UPLOAD_WORKSHOP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_UPLOAD_WORKSHOP` (
  `ID` int(11) NOT NULL,
  `BATCHNO` int(11) DEFAULT NULL,
  `IMPORT_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_UPDATE_DT` datetime DEFAULT NULL,
  `LOC_CODE` varchar(8) DEFAULT NULL,
  `ADMIN_NAME` varchar(80) DEFAULT NULL,
  `WSDATE` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_UPLOAD_WORKSHOP`
--

LOCK TABLES `PWI_UPLOAD_WORKSHOP` WRITE;
/*!40000 ALTER TABLE `PWI_UPLOAD_WORKSHOP` DISABLE KEYS */;
INSERT INTO `PWI_UPLOAD_WORKSHOP` VALUES (10592,100,'2006-06-09 04:10:23','2003-06-10 11:40:03','Z102','Tammy Tougas','0000-00-00'),(10493,100,'2006-06-09 04:10:23','2003-06-10 14:33:32','SC19','Tammy Tougas','0000-00-00'),(10552,100,'2006-06-09 04:10:23','2003-06-12 11:58:56','NC15','Holly King','0000-00-00'),(10597,100,'2006-06-09 04:10:23','2003-06-19 08:43:39','LV13','Catherine Webb','0000-00-00'),(10489,100,'2006-06-09 04:10:23','2003-06-24 11:53:58','SC19','Tammy Tougas','0000-00-00'),(10534,100,'2006-06-09 04:10:23','2003-06-26 10:20:39','AZ05','Holly King','0000-00-00'),(10536,100,'2006-06-09 04:10:23','2003-07-03 12:19:41','AZ05','Holly King','0000-00-00'),(10553,100,'2006-06-09 04:10:23','2003-07-03 12:20:15','NC15','Holly King','0000-00-00'),(10565,100,'2006-06-09 04:10:23','2003-07-03 12:22:09','WE01','Holly King','0000-00-00'),(10538,100,'2006-06-09 04:10:23','2003-08-08 10:58:07','AZ05','Holly King','0000-00-00'),(10554,100,'2006-06-09 04:10:23','2003-08-08 10:58:53','NC07','Holly King','0000-00-00'),(10566,100,'2006-06-09 04:10:23','2003-08-08 12:43:53','WE01','Holly King','0000-00-00'),(10564,100,'2006-06-09 04:10:23','2003-08-14 12:25:23','WE01','Holly King','0000-00-00'),(10516,100,'2006-06-09 04:10:23','2003-08-18 08:45:40','SC19','Tammy Tougas','0000-00-00'),(10495,100,'2006-06-09 04:10:23','2003-08-18 10:35:51','SC19','Tammy Tougas','0000-00-00'),(10499,100,'2006-06-09 04:10:23','2003-08-20 14:34:06','SC19','Tammy Tougas','0000-00-00'),(10599,100,'2006-06-09 04:10:23','2003-08-27 12:01:38','UT05','Catherine Webb','0000-00-00'),(10539,100,'2006-06-09 04:10:23','2003-09-04 08:29:46','AZ05','Holly King','0000-00-00'),(10501,100,'2006-06-09 04:10:23','2003-09-04 08:55:39','SC19','Tammy Tougas','0000-00-00'),(10567,100,'2006-06-09 04:10:23','2003-09-16 11:15:12','WE01','Holly King','0000-00-00'),(10540,100,'2006-06-09 04:10:23','2003-09-18 14:20:30','AZ05','Holly King','0000-00-00'),(10555,100,'2006-06-09 04:10:23','2003-09-19 09:01:41','NC15','Holly King','0000-00-00'),(10541,100,'2006-06-09 04:10:23','2003-10-01 14:03:02','AZ05','Holly King','0000-00-00'),(10542,100,'2006-06-09 04:10:23','2003-10-16 09:27:04','AZ05','Holly King','0000-00-00'),(10568,100,'2006-06-09 04:10:23','2003-10-16 09:33:35','WE01','Holly King','0000-00-00'),(10507,100,'2006-06-09 04:10:23','2003-10-21 10:45:56','SC19','Tammy Tougas','0000-00-00'),(10550,100,'2006-06-09 04:10:23','2003-10-21 13:56:58','NC15','Holly King','0000-00-00'),(10556,100,'2006-06-09 04:10:23','2003-10-23 16:20:54','NC15','Holly King','0000-00-00'),(10642,100,'2006-06-09 04:10:23','2003-10-28 14:30:11','SC19','Tammy Tougas','0000-00-00'),(10650,100,'2006-06-09 04:10:23','2003-10-28 14:33:08','SC19','Tammy Tougas','0000-00-00'),(10543,100,'2006-06-09 04:10:23','2003-11-03 13:50:15','AZ05','Holly King','0000-00-00'),(10509,100,'2006-06-09 04:10:23','2003-11-06 14:12:23','SC19','Tammy Tougas','0000-00-00'),(10544,100,'2006-06-09 04:10:23','2003-11-11 15:42:28','AZ05','Holly King','0000-00-00'),(10557,100,'2006-06-09 04:10:23','2003-11-13 08:46:28','NC15','Holly King','0000-00-00'),(10569,100,'2006-06-09 04:10:23','2003-11-13 08:46:56','WE01','Holly King','0000-00-00'),(10545,100,'2006-06-09 04:10:23','2003-11-18 10:22:44','AZ05','Holly King','0000-00-00'),(10641,100,'2006-06-09 04:10:23','2003-12-16 15:52:44','SC18','Tammy Tougas','0000-00-00'),(10620,100,'2006-06-09 04:10:23','2003-12-23 11:01:38','AZ05','Holly King','0000-00-00'),(10593,100,'2006-06-09 04:10:23','2003-12-23 11:12:04','WE01','Holly King','0000-00-00'),(10600,100,'2006-06-09 04:10:23','2003-12-31 12:03:17','NC15','Holly King','0000-00-00'),(10621,100,'2006-06-09 04:10:23','2004-01-06 15:25:34','AZ05','Holly King','0000-00-00'),(10601,100,'2006-06-09 04:10:23','2004-01-14 13:04:51','NC15','Holly King','0000-00-00'),(10594,100,'2006-06-09 04:10:23','2004-01-26 10:03:11','WE01','Holly King','0000-00-00'),(10644,100,'2006-06-09 04:10:23','2004-01-27 08:23:42','SC19','Tammy Tougas','0000-00-00'),(10623,100,'2006-06-09 04:10:23','2004-02-05 10:14:24','AZ05','Holly King','0000-00-00'),(10646,100,'2006-06-09 04:10:23','2004-02-10 11:25:40','SC19','Tammy Tougas','0000-00-00'),(10645,100,'2006-06-09 04:10:23','2004-02-11 13:46:43','SC19','Tammy Tougas','0000-00-00'),(10647,100,'2006-06-09 04:10:23','2004-02-13 11:32:38','SC19','Tammy Tougas','0000-00-00'),(10602,100,'2006-06-09 04:10:23','2004-02-17 12:25:39','NC15','Holly King','0000-00-00'),(10595,100,'2006-06-09 04:10:23','2004-02-17 12:29:09','WE01','Holly King','0000-00-00'),(10648,100,'2006-06-09 04:10:23','2004-02-25 14:10:16','SC19','Tammy Tougas','0000-00-00'),(10625,100,'2006-06-09 04:10:23','2004-03-03 09:08:30','AZ05','Holly King','0000-00-00'),(10649,100,'2006-06-09 04:10:23','2004-03-16 09:18:56','SC19','Tammy Tougas','0000-00-00'),(10603,100,'2006-06-09 04:10:23','2004-03-16 14:43:29','NC15','Holly King','0000-00-00'),(10596,100,'2006-06-09 04:10:23','2004-03-22 10:05:31','WE01','Holly King','0000-00-00'),(10626,100,'2006-06-09 04:10:23','2004-03-30 11:00:31','AZ05','Holly King','0000-00-00'),(10627,100,'2006-06-09 04:10:23','2004-04-12 08:38:27','AZ05','Holly King','0000-00-00'),(10628,100,'2006-06-09 04:10:23','2004-04-12 15:25:41','AZ05','Holly King','0000-00-00'),(10612,100,'2006-06-09 04:10:23','2004-04-12 15:26:13','WE01','Holly King','0000-00-00'),(10653,100,'2006-06-09 04:10:23','2004-04-13 10:56:57','SC19','Tammy Tougas','0000-00-00'),(10654,100,'2006-06-09 04:10:23','2004-04-16 11:39:32','SC19','Tammy Tougas','0000-00-00'),(10604,100,'2006-06-09 04:10:23','2004-04-19 11:17:48','NC15','Holly King','0000-00-00'),(10655,100,'2006-06-09 04:10:23','2004-04-28 15:10:13','SC19','Tammy Tougas','0000-00-00'),(10629,100,'2006-06-09 04:10:23','2004-04-30 12:26:18','AZ05','Holly King','0000-00-00'),(10630,100,'2006-06-09 04:10:23','2004-05-19 12:39:00','AZ05','Holly King','0000-00-00'),(10656,100,'2006-06-09 04:10:23','2004-05-21 09:00:39','SC19','Tammy Tougas','0000-00-00'),(10605,100,'2006-06-09 04:10:23','2004-05-21 09:26:31','NC15','Holly King','0000-00-00'),(10631,100,'2006-06-09 04:10:23','2004-06-03 09:59:13','AZ05','Holly King','0000-00-00'),(10657,100,'2006-06-09 04:10:23','2004-06-09 10:17:11','SC19','Tammy Tougas','0000-00-00'),(10614,100,'2006-06-09 04:10:23','2004-06-22 15:45:28','WE01','Holly King','0000-00-00'),(10606,100,'2006-06-09 04:10:23','2004-06-22 15:45:48','NC15','Holly King','0000-00-00'),(10632,100,'2006-06-09 04:10:23','2004-06-24 09:52:01','AZ05','Holly King','0000-00-00'),(10660,100,'2006-06-09 04:10:23','2004-07-13 10:45:11','SC19','Tammy Tougas','0000-00-00'),(10607,100,'2006-06-09 04:10:23','2004-07-14 09:59:43','NC15','Holly King','0000-00-00'),(10658,100,'2006-06-09 04:10:23','2004-07-14 14:05:52','SC19','Tammy Tougas','0000-00-00'),(10615,100,'2006-06-09 04:10:23','2004-07-14 14:08:36','WE01','Holly King','0000-00-00'),(10661,100,'2006-06-09 04:10:23','2004-07-28 10:32:58','SC19','Tammy Tougas','0000-00-00'),(10633,100,'2006-06-09 04:10:23','2004-08-02 11:06:36','AZ05','Holly King','0000-00-00'),(10662,100,'2006-06-09 04:10:23','2004-08-10 12:05:40','SC19','Tammy Tougas','0000-00-00'),(10608,100,'2006-06-09 04:10:23','2004-08-16 09:11:23','NC15','Holly King','0000-00-00'),(10664,100,'2006-06-09 04:10:23','2004-08-24 10:38:39','SC20','Tammy Tougas','0000-00-00'),(10735,100,'2006-06-09 04:10:23','2004-08-27 08:20:42','SC19','Tammy Tougas','0000-00-00'),(10635,100,'2006-06-09 04:10:23','2004-09-07 11:27:50','AZ05','Holly King','0000-00-00'),(10666,100,'2006-06-09 04:10:23','2004-09-07 15:35:43','SC19','Tammy Tougas','0000-00-00'),(10694,100,'2006-06-09 04:10:23','2004-09-07 16:11:19','SC19','Tammy Tougas','0000-00-00'),(10729,100,'2006-06-09 04:10:23','2004-09-07 16:16:32','SC19','Tammy Tougas','0000-00-00'),(10730,100,'2006-06-09 04:10:23','2004-09-07 16:17:17','SC19','Tammy Tougas','0000-00-00'),(10609,100,'2006-06-09 04:10:23','2004-09-17 11:55:33','NC15','Holly King','0000-00-00'),(10636,100,'2006-06-09 04:10:23','2004-09-17 11:56:17','AZ05','Holly King','0000-00-00'),(10667,100,'2006-06-09 04:10:23','2004-09-21 09:44:30','SC19','Tammy Tougas','0000-00-00'),(10668,100,'2006-06-09 04:10:23','2004-10-01 09:39:33','SC19','Tammy Tougas','0000-00-00'),(10637,100,'2006-06-09 04:10:23','2004-10-04 09:21:19','AZ05','Holly King','0000-00-00'),(10618,100,'2006-06-09 04:10:23','2004-10-18 15:19:10','WE01','Holly King','0000-00-00'),(10638,100,'2006-06-09 04:10:23','2004-10-19 10:20:17','AZ05','Holly King','0000-00-00'),(10610,100,'2006-06-09 04:10:23','2004-10-20 10:47:56','NC15','Holly King','0000-00-00'),(10669,100,'2006-06-09 04:10:23','2004-10-29 16:19:57','SC19','Tammy Tougas','0000-00-00'),(10639,100,'2006-06-09 04:10:23','2004-11-01 11:27:24','AZ05','Holly King','0000-00-00'),(10671,100,'2006-06-09 04:10:23','2004-11-03 09:11:29','SC19','Tammy Tougas','0000-00-00'),(10619,100,'2006-06-09 04:10:23','2004-11-04 12:01:48','WE01','Holly King','0000-00-00'),(10640,100,'2006-06-09 04:10:23','2004-11-04 12:27:40','AZ05','Holly King','0000-00-00');
/*!40000 ALTER TABLE `PWI_UPLOAD_WORKSHOP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_WORKSHOP`
--

DROP TABLE IF EXISTS `PWI_WORKSHOP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_WORKSHOP` (
  `WS_KV` int(11) NOT NULL,
  `WS_ID` varchar(20) NOT NULL,
  `WS_LOCREF` int(11) NOT NULL,
  `WS_STATUSREF` int(11) NOT NULL DEFAULT '1',
  `WS_DUEDATE` date DEFAULT NULL,
  `WS_STARTDATE` date DEFAULT NULL,
  `WS_REMDATE1` date DEFAULT NULL,
  `WS_REMDATE2` date DEFAULT NULL,
  PRIMARY KEY (`WS_KV`),
  UNIQUE KEY `WS_ID` (`WS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_WORKSHOP`
--

LOCK TABLES `PWI_WORKSHOP` WRITE;
/*!40000 ALTER TABLE `PWI_WORKSHOP` DISABLE KEYS */;
INSERT INTO `PWI_WORKSHOP` VALUES (1,'1',1,1,'2006-05-29',NULL,'2006-05-26','0000-00-00'),(2,'10592',122,1,NULL,'0000-00-00',NULL,NULL),(3,'10493',128,1,NULL,'0000-00-00',NULL,NULL),(4,'10552',132,1,NULL,'0000-00-00',NULL,NULL),(5,'10597',121,1,NULL,'0000-00-00',NULL,NULL),(6,'10489',128,1,NULL,'0000-00-00',NULL,NULL),(7,'10534',133,1,NULL,'0000-00-00',NULL,NULL),(8,'10536',133,1,NULL,'0000-00-00',NULL,NULL),(9,'10553',132,1,NULL,'0000-00-00',NULL,NULL),(10,'10565',106,1,NULL,'0000-00-00',NULL,NULL),(11,'10538',133,1,NULL,'0000-00-00',NULL,NULL),(12,'10554',23,1,NULL,'0000-00-00',NULL,NULL),(13,'10566',106,1,NULL,'0000-00-00',NULL,NULL),(14,'10564',106,1,NULL,'0000-00-00',NULL,NULL),(15,'10516',128,1,NULL,'0000-00-00',NULL,NULL),(16,'10495',128,1,NULL,'0000-00-00',NULL,NULL),(17,'10499',128,1,NULL,'0000-00-00',NULL,NULL),(18,'10599',123,1,NULL,'0000-00-00',NULL,NULL),(19,'10539',133,1,NULL,'0000-00-00',NULL,NULL),(20,'10501',128,1,NULL,'0000-00-00',NULL,NULL),(21,'10567',106,1,NULL,'0000-00-00',NULL,NULL),(22,'10540',133,1,NULL,'0000-00-00',NULL,NULL),(23,'10555',132,1,NULL,'0000-00-00',NULL,NULL),(24,'10541',133,1,NULL,'0000-00-00',NULL,NULL),(25,'10542',133,1,NULL,'0000-00-00',NULL,NULL),(26,'10568',106,1,NULL,'0000-00-00',NULL,NULL),(27,'10507',128,1,NULL,'0000-00-00',NULL,NULL),(28,'10550',132,1,NULL,'0000-00-00',NULL,NULL),(29,'10556',132,1,NULL,'0000-00-00',NULL,NULL),(30,'10642',128,1,NULL,'0000-00-00',NULL,NULL),(31,'10650',128,1,NULL,'0000-00-00',NULL,NULL),(32,'10543',133,1,NULL,'0000-00-00',NULL,NULL),(33,'10509',128,1,NULL,'0000-00-00',NULL,NULL),(34,'10544',133,1,NULL,'0000-00-00',NULL,NULL),(35,'10557',132,1,NULL,'0000-00-00',NULL,NULL),(36,'10569',106,1,NULL,'0000-00-00',NULL,NULL),(37,'10545',133,1,NULL,'0000-00-00',NULL,NULL),(38,'10641',127,1,NULL,'0000-00-00',NULL,NULL),(39,'10620',133,1,NULL,'0000-00-00',NULL,NULL),(40,'10593',106,1,NULL,'0000-00-00',NULL,NULL),(41,'10600',132,1,NULL,'0000-00-00',NULL,NULL),(42,'10621',133,1,NULL,'0000-00-00',NULL,NULL),(43,'10601',132,1,NULL,'0000-00-00',NULL,NULL),(44,'10594',106,1,NULL,'0000-00-00',NULL,NULL),(45,'10644',128,1,NULL,'0000-00-00',NULL,NULL),(46,'10623',133,1,NULL,'0000-00-00',NULL,NULL),(47,'10646',128,1,NULL,'0000-00-00',NULL,NULL),(48,'10645',128,1,NULL,'0000-00-00',NULL,NULL),(49,'10647',128,1,NULL,'0000-00-00',NULL,NULL),(50,'10602',132,1,NULL,'0000-00-00',NULL,NULL),(51,'10595',106,1,NULL,'0000-00-00',NULL,NULL),(52,'10648',128,1,NULL,'0000-00-00',NULL,NULL),(53,'10625',133,1,NULL,'0000-00-00',NULL,NULL),(54,'10649',128,1,NULL,'0000-00-00',NULL,NULL),(55,'10603',132,1,NULL,'0000-00-00',NULL,NULL),(56,'10596',106,1,NULL,'0000-00-00',NULL,NULL),(57,'10626',133,1,NULL,'0000-00-00',NULL,NULL),(58,'10627',133,1,NULL,'0000-00-00',NULL,NULL),(59,'10628',133,1,NULL,'0000-00-00',NULL,NULL),(60,'10612',106,1,NULL,'0000-00-00',NULL,NULL),(61,'10653',128,1,NULL,'0000-00-00',NULL,NULL),(62,'10654',128,1,NULL,'0000-00-00',NULL,NULL),(63,'10604',132,1,NULL,'0000-00-00',NULL,NULL),(64,'10655',128,1,NULL,'0000-00-00',NULL,NULL),(65,'10629',133,1,NULL,'0000-00-00',NULL,NULL),(66,'10630',133,1,NULL,'0000-00-00',NULL,NULL),(67,'10656',128,1,NULL,'0000-00-00',NULL,NULL),(68,'10605',132,1,NULL,'0000-00-00',NULL,NULL),(69,'10631',133,1,NULL,'0000-00-00',NULL,NULL),(70,'10657',128,1,NULL,'0000-00-00',NULL,NULL),(71,'10614',106,1,NULL,'0000-00-00',NULL,NULL),(72,'10606',132,1,NULL,'0000-00-00',NULL,NULL),(73,'10632',133,1,NULL,'0000-00-00',NULL,NULL),(74,'10660',128,1,NULL,'0000-00-00',NULL,NULL),(75,'10607',132,1,NULL,'0000-00-00',NULL,NULL),(76,'10658',128,1,NULL,'0000-00-00',NULL,NULL),(77,'10615',106,1,NULL,'0000-00-00',NULL,NULL),(78,'10661',128,1,NULL,'0000-00-00',NULL,NULL),(79,'10633',133,1,NULL,'0000-00-00',NULL,NULL),(80,'10662',128,1,NULL,'0000-00-00',NULL,NULL),(81,'10608',132,1,NULL,'0000-00-00',NULL,NULL),(82,'10664',130,1,NULL,'0000-00-00',NULL,NULL),(83,'10735',128,1,'2012-05-12','2012-06-01','2012-05-01','2012-05-15'),(84,'10635',133,1,NULL,'0000-00-00',NULL,NULL),(85,'10666',128,1,NULL,'0000-00-00',NULL,NULL),(86,'10694',128,1,NULL,'0000-00-00',NULL,NULL),(87,'10729',128,1,NULL,'0000-00-00',NULL,NULL),(88,'10730',128,1,NULL,'0000-00-00',NULL,NULL),(89,'10609',132,1,NULL,'0000-00-00',NULL,NULL),(90,'10636',133,1,NULL,'0000-00-00',NULL,NULL),(91,'10667',128,1,NULL,'0000-00-00',NULL,NULL),(92,'10668',128,1,NULL,'0000-00-00',NULL,NULL),(93,'10637',133,1,NULL,'0000-00-00',NULL,NULL),(94,'10618',106,1,NULL,'0000-00-00',NULL,NULL),(95,'10638',133,1,NULL,'0000-00-00',NULL,NULL),(96,'10610',132,1,NULL,'0000-00-00',NULL,NULL),(97,'10669',128,1,NULL,'0000-00-00',NULL,NULL),(98,'10639',133,1,NULL,'0000-00-00',NULL,NULL),(99,'10671',128,1,NULL,'0000-00-00',NULL,NULL),(100,'10619',106,1,NULL,'0000-00-00',NULL,NULL),(101,'10640',133,1,NULL,'0000-00-00',NULL,NULL);
/*!40000 ALTER TABLE `PWI_WORKSHOP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWI_WSSTATUS`
--

DROP TABLE IF EXISTS `PWI_WSSTATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PWI_WSSTATUS` (
  `WSS_KV` int(11) NOT NULL,
  `WSS_NUM` int(11) NOT NULL,
  `WSS_STATUS` varchar(15) NOT NULL,
  PRIMARY KEY (`WSS_KV`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWI_WSSTATUS`
--

LOCK TABLES `PWI_WSSTATUS` WRITE;
/*!40000 ALTER TABLE `PWI_WSSTATUS` DISABLE KEYS */;
INSERT INTO `PWI_WSSTATUS` VALUES (1,1,'Open'),(2,2,'Closing'),(3,3,'Closed'),(4,4,'Cancelled');
/*!40000 ALTER TABLE `PWI_WSSTATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TUSER`
--

DROP TABLE IF EXISTS `TUSER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TUSER` (
  `UID` varchar(20) NOT NULL,
  `PWD` varchar(20) NOT NULL,
  `FIRSTNAME` varchar(50) DEFAULT NULL,
  `LASTNAME` varchar(50) DEFAULT NULL,
  `CLID` int(11) NOT NULL,
  PRIMARY KEY (`UID`),
  KEY `CLID` (`CLID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TUSER`
--

LOCK TABLES `TUSER` WRITE;
/*!40000 ALTER TABLE `TUSER` DISABLE KEYS */;
INSERT INTO `TUSER` VALUES ('ac','12345','Andrew','Creer',1),('mikkel','Nautilus!','Mike','King',1),('cesa','Kids123','Ian','Cesa',1),('jmuska','t88ghone','jan','Muska',1),('skye','Eyks123','Skye','Stamey',1),('mzheng','zm74326','Mo','Zheng',1),('jwcarter','terr0ri2e','John','Carter',1),('colleen','m0n1que','Colleen','Atarinyw',1),('mfeely','7b.8mdi','Michael','Feely',1);
/*!40000 ALTER TABLE `TUSER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UFIELD`
--

DROP TABLE IF EXISTS `UFIELD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UFIELD` (
  `KEYVAL` int(11) NOT NULL,
  `SURVEY_REF` int(11) NOT NULL,
  `SID` varchar(10) DEFAULT NULL,
  `FNAME` varchar(15) DEFAULT NULL,
  `FTYPE` varchar(10) DEFAULT NULL,
  `FLEN` int(11) DEFAULT NULL,
  PRIMARY KEY (`KEYVAL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UFIELD`
--

LOCK TABLES `UFIELD` WRITE;
/*!40000 ALTER TABLE `UFIELD` DISABLE KEYS */;
/*!40000 ALTER TABLE `UFIELD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VACCESS`
--

DROP TABLE IF EXISTS `VACCESS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VACCESS` (
  `VID` int(11) NOT NULL,
  `UID` varchar(20) NOT NULL,
  `J_CREATE` int(11) NOT NULL,
  `J_READ` int(11) NOT NULL,
  `J_USE` int(11) NOT NULL,
  `J_DELETE` int(11) NOT NULL,
  PRIMARY KEY (`VID`,`UID`),
  KEY `UID` (`UID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VACCESS`
--

LOCK TABLES `VACCESS` WRITE;
/*!40000 ALTER TABLE `VACCESS` DISABLE KEYS */;
INSERT INTO `VACCESS` VALUES (1,'ac',1,1,1,1),(1,'mikkel',1,1,1,1),(1,'cesa',1,1,1,1),(1,'jmuska',1,1,1,1),(1,'skye',1,1,1,1),(1,'mzheng',1,1,1,1),(1,'jwcarter',1,1,1,1),(1,'colleen',1,1,1,1),(1,'mfeely',1,1,1,1);
/*!40000 ALTER TABLE `VACCESS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VHOST`
--

DROP TABLE IF EXISTS `VHOST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VHOST` (
  `VID` int(11) NOT NULL,
  `VDOMAIN` varchar(50) NOT NULL,
  `DEF_EMAIL` varchar(50) NOT NULL,
  `VHOSTROOT` varchar(70) NOT NULL,
  `SERVERROOT` varchar(70) NOT NULL,
  `DOCUMENTROOT` varchar(70) NOT NULL,
  `TRITONROOT` varchar(70) NOT NULL,
  `CVSROOT` varchar(70) NOT NULL,
  `CGI_MR` varchar(70) NOT NULL,
  `SCRIPTS` varchar(70) NOT NULL,
  `TEMPLATES` varchar(70) NOT NULL,
  PRIMARY KEY (`VID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VHOST`
--

LOCK TABLES `VHOST` WRITE;
/*!40000 ALTER TABLE `VHOST` DISABLE KEYS */;
INSERT INTO `VHOST` VALUES (1,'pwikit','ac@market-research.com','/home/triton/pwikit','/usr/local/apache','/home/triton/pwikit/htdocs','/home/triton/pwikit/triton','/home/triton/pwikit/cvs','/home/triton/pwikit/cgi-mr','/home/triton/pwikit/scripts','/home/triton/pwikit/triton/templates');
/*!40000 ALTER TABLE `VHOST` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-04-16  6:21:08
